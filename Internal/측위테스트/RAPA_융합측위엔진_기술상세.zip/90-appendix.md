# 90. 부록 — 참고문헌 · 재현성 · 용어집

> **버전** v0.1-draft · **날짜** 2026-06-25 · **상태** 초안
> 이 파일(Part 90)은 방법론 문서 전체(00–30)의 부록이다. 본문 각 파일의 인라인 `[Author Year]` 인용을 정식 표기로 수집하고, 재현에 필요한 파라미터·기기·실행 정보를 표로 제시하며, 핵심 기술 용어를 정의한다.

---

## 부록 A. 참고문헌

본 절은 방법론 문서 00-overview, 10-core-capture-vps, 11-core-fusion, 12-core-drift-validation, 20-platform-android, 21-platform-ios, 30-compare-converge에서 사용된 `[Author Year]` 형식 인용 키를 전수 수집하여 정식 표기한 목록이다. 알파벳 순 정렬.

---

**[Arandjelović 2016]**
Relja Arandjelović, Petr Gronát, Akihiko Torii, Tomás Pajdla, Josef Sivic.
"NetVLAD: CNN Architecture for Weakly Supervised Place Recognition."
*Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 5297–5307.
https://doi.org/10.1109/CVPR.2016.572

---

**[Arulampalam 2002]**
M. Sanjeev Arulampalam, Simon Maskell, Neil Gordon, Tim Clapp.
"A Tutorial on Particle Filters for Online Nonlinear/Non-Gaussian Bayesian Tracking."
*IEEE Transactions on Signal Processing*, vol. 50, no. 2, pp. 174–188, February 2002.
https://doi.org/10.1109/78.978374

---

**[Bar-Shalom 2002]**
Yaakov Bar-Shalom.
"Update with Out-of-Sequence Measurements in Tracking: Exact Solution."
*IEEE Transactions on Aerospace and Electronic Systems*, vol. 38, no. 3, pp. 769–777, July 2002.
https://doi.org/10.1109/TAES.2002.1039398

---

**[Bar-Shalom 2004]**
Yaakov Bar-Shalom, Huimin Chen, Mathias Mallick.
"One-Step Solution for the Multistep Out-of-Sequence-Measurement Problem in Tracking."
*IEEE Transactions on Aerospace and Electronic Systems*, vol. 40, no. 1, pp. 27–37, January 2004.
https://doi.org/10.1109/TAES.2004.1292141

---

**[DeTone 2018]**
Daniel DeTone, Tomasz Malisiewicz, Andrew Rabinovich.
"SuperPoint: Self-Supervised Interest Point Detection and Description."
*Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition Workshops (CVPRW)*, 2018, pp. 224–236.
https://doi.org/10.1109/CVPRW.2018.00060

---

**[Guo 2025]**
Pengzhan Guo, Guiling Sun, Peng Zhao, Guangping Wang, Lin Mei.
"Robust Magnetic Fingerprint Positioning with Complex Indoor Environment Using Res-T-LSTM."
*Sensors*, vol. 25, no. 24, article 7464, 2025.
https://doi.org/10.3390/s25247464

---

**[Herath 2020]**
Sachini Herath, Hang Yan, Yasutaka Furukawa.
"RoNIN: Robust Neural Inertial Navigation in the Wild: Benchmark, Evaluations, and New Methods."
*Proceedings of the IEEE International Conference on Robotics and Automation (ICRA)*, 2020, pp. 3146–3152.
https://doi.org/10.1109/ICRA40945.2020.9197340

---

**[Jayanth 2025]**
Rohan Jayanth, Longning Li, Luca Carlone.
"EqNIO: Equivariant Neural Inertial Odometry."
*Proceedings of the International Conference on Learning Representations (ICLR)*, 2025.
arXiv: https://arxiv.org/abs/2410.00967

---

**[Lindenberger 2023]**
Philipp Lindenberger, Paul-Edouard Sarlin, Marc Pollefeys.
"LightGlue: Local Feature Matching at Light Speed."
*Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV)*, 2023, pp. 17627–17638.
https://doi.org/10.1109/ICCV51070.2023.01616

---

**[Liu 2020]** (also cited as **[Liu 2020, TLIO]**)
Wenxin Liu, David Caruso, Eddy Ilg, Jing Dong, Anastasios I. Mourikis, Kostas Daniilidis, Vijay Kumar, Jakob Engel.
"TLIO: Tight Learned Inertial Odometry."
*IEEE Robotics and Automation Letters (RA-L)*, vol. 5, no. 4, pp. 5653–5660, October 2020.
https://doi.org/10.1109/LRA.2020.3007421

---

**[Ott 2021]**
Kenneth Ott, René Ranftl, Fisher Yu, Thomas Brox.
"StrayScanner: A Capture App for Everyday Indoor 3D Scanning."
GitHub repository / documentation, 2021.
https://github.com/kekeblom/StrayScanner

---

**[Sarlin 2019]**
Paul-Edouard Sarlin, Cesar Cadena, Roland Siegwart, Marcin Dymczyk.
"From Coarse to Fine: Robust Hierarchical Localization at Large Scale."
*Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2019, pp. 12716–12725.
https://doi.org/10.1109/CVPR.2019.01300
(hloc — Hierarchical Localization framework, https://github.com/cvg/Hierarchical-Localization)

---

**[Sarlin 2022]**
Paul-Edouard Sarlin, Mihai Dusmanu, Johannes L. Schönberger, Pablo Speciale, Lukas Gruber, Viktor Larsson, Ondrej Miksik, Marc Pollefeys.
"LaMAR: Benchmarking Localization and Mapping for Augmented Reality."
*Proceedings of the European Conference on Computer Vision (ECCV)*, 2022, pp. 686–704.
https://doi.org/10.1007/978-3-031-20071-7_40

---

**[Schönberger 2016]**
Johannes Lutz Schönberger, Jan-Michael Frahm.
"Structure-from-Motion Revisited."
*Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 4104–4113.
https://doi.org/10.1109/CVPR.2016.445
(COLMAP SfM system, https://github.com/colmap/colmap)

---

**[Solin 2018]**
Arno Solin, Simo Särkkä, Juho Kannala, Esa Rahtu.
"Terrain Navigation in the Magnetic Landscape: Particle Filtering for Indoor Positioning."
*Proceedings of the 26th European Signal Processing Conference (EUSIPCO)*, 2018, pp. 1–5.
https://doi.org/10.23919/EUSIPCO.2018.8553374

---

**[Umeyama 1991]**
Shinji Umeyama.
"Least-Squares Estimation of Transformation Parameters Between Two Point Patterns."
*IEEE Transactions on Pattern Analysis and Machine Intelligence (TPAMI)*, vol. 13, no. 4, pp. 376–380, April 1991.
https://doi.org/10.1109/34.88573

---

**[Vovk 2005]**
Vladimir Vovk, Alex Gammerman, Glenn Shafer.
*Algorithmic Learning in a Random World.*
Springer, 2005. ISBN 978-0-387-00152-4.
(Conformal prediction 이론의 원저; inductive CP는 §5.3 참조)

---

## 부록 B. 재현성 (파라미터·기기·실행)

### B.1 핵심 파라미터 표

아래 표는 `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/live/PositioningEngine.kt`의 `Config` 및 관련 코드에서 코드 수준으로 검증된 값이다.

| 파라미터 | 값 | 단위 | 출처 |
|---|---|---|---|
| `nParticles` | 2000 | 개 | `PositioningEngine.kt` Config |
| `motionSigma` | 0.02 | m | `PositioningEngine.kt` Config |
| `headingSigma` | 0.01 | rad | `PositioningEngine.kt` Config |
| `scaleK` | 1.31 | — | `PositioningEngine.kt` Config |
| `scaleKSpread` | 0.0 | — | `ParticleFilter.kt` 생성자 기본값 |
| `absFixGateSigma` | 5.0 | σ | `PositioningEngine.kt` Config |
| `maxAbsFixRejects` | 3 | 회 | `PositioningEngine.kt` Config |
| `vpsHeadingResetSpreadRad` | 5 × π/180 ≈ 0.0873 | rad | `PositioningEngine.kt` Config |
| N_eff 리샘플 임계 | 0.5 × N = 1000 | — | `ParticleFilter.kt` `neff() < 0.5 * n` |
| GravityAlignedResampler 그리드 간격 (DT_NS) | 5,000,000 | ns | `GravityAlignedResampler.kt` |
| EqNIO 입력 샘플레이트 | 200 | Hz | DT_NS = 5 ms → 1/0.005 s |
| EqNIO 슬라이딩 윈도우 크기 (WINDOW) | 200 | 샘플 | `NeuralOdometry.kt` |
| EqNIO 슬라이딩 스텝 (STEP) | 10 | 샘플 | `NeuralOdometry.kt` |
| EqNIO 방출 주기 | ~20 | Hz | STEP × 5 ms = 50 ms |
| yawHist 링버퍼 보관 시간 | 30 | s | `PositioningEngine.kt` `yawHistMaxAgeNs` |
| MagneticLocator 윈도우 크기 | 3.0 | m | `Engine.swift:76` / `MagneticLocator.kt` |
| MagneticLocator 최소 누적 이동 | 2.0 | m | `Engine.swift:76` |
| MagneticLocator RMS 게이트 | 5 | µT | `Engine.swift:76` (`gateUt = 5.0`) |
| MagneticLocator 픽스 σ | 0.6 | m | `Engine.swift:76` (`sigmaM = 0.6`) |
| MagneticLocator 방출 간격 | 0.5 | m | `Engine.swift:76` (`emitStepM = 0.5`) |
| parity 허용 오차 Δx / Δy | ≤ 0.05 | m | `vps/test_parity.py` `TOL` |
| parity 허용 오차 Δθ | ≤ 0.02 | rad | `vps/test_parity.py` `TOL` |
| parity 허용 오차 Δinliers | ≤ 8 | — | `vps/test_parity.py` `TOL` |
| parity 지연 게이트 | < 5,000 | ms | `vps/test_parity.py` warm gate |
| `measSigmaPerCh` (자기 채널 설정) | [1e6, 4.0] | µT | `PositioningEngine.kt` (현행 검증값; `|B_xy|` 사실상 차단, `B_z` σ = 4 µT) |
| softWallFactor | 0.1 | — | `ParticleFilter.kt` SOFT 모드 가중치 감쇄 계수 |

### B.2 기기 및 서베이 세션

| 항목 | 값 |
|---|---|
| 캡처 기기 | iPhone 15 Pro (iPhone15,3), iOS 27 Beta |
| Xcode 빌드 환경 | Xcode-beta 27.0 |
| Apple 개발팀 | M9QXG9P6HU |
| VPS 맵빌드 서베이 세션 | `20260623-113521` |
| 서베이 이미지 수 | 500장 |
| 서베이 3D 점 수 | 38,610개 |
| VPS reproj 오차 (중앙값) | 1.67 px |
| VPS hold-out 위치오차 (중앙값) | 7.6 cm |
| 서베이 커버리지 | 67 m² (도면 29%) |
| EqNIO 모델 파일 | `eqnio_o2.onnx` |

### B.3 빌드 및 실행 절차

#### VPS 파이프라인 (오프라인 맵빌드)

```
# 1. ARKit → COLMAP 변환
python vps/arkit_to_colmap.py --session 20260623-113521

# 2. hloc 맵빌드 (SuperPoint + LightGlue)
python vps/build_map.py

# 3. VPS 서비스 기동 (모델 영속화, MPS + CPU 하이브리드)
python vps/vps_service.py   # 포트 8765

# 4. 홀드아웃 측위 검증
python vps/localize.py --holdout
```

#### Golden-Replay Parity 테스트 절차

1. VPS 서비스 기동: `python vps/vps_service.py` (포트 8765)
2. `vps/parity_golden.json`에 기준 이미지 5장의 GT 값 저장 확인
3. parity 테스트 실행: `python vps/test_parity.py`
4. 합격 조건:
   - `PARITY OK (N장 일치)` — Δx/Δy ≤ 0.05 m, Δθ ≤ 0.02 rad, Δinliers ≤ 8
   - `지연 게이트 OK (<5000ms)` — 지연 중앙값 < 5,000 ms
5. 코드 변경(모델 업데이트, 리팩터링 등) 후 CI에서 반드시 통과 확인

#### iOS 앱 빌드

```
# Xcode-beta 27.0 에서 RapaCapture 스킴 선택
# 팀 M9QXG9P6HU 코드사이닝
# 기기: iPhone 15 Pro (iOS 27 Beta) 유선 연결 후 빌드
xcodebuild -scheme RapaCapture -destination 'platform=iOS,name=iPhone 15 Pro'
```

---

## 부록 C. 용어집

아래 용어는 방법론 문서 전체에서 정의 없이 사용된 기술 용어를 알파벳 순으로 정의한다.

---

**ATE (Absolute Trajectory Error)**
추정 궤적과 GT(ground truth) 궤적 간의 전체 정렬 후 RMSE. 상사변환(Umeyama [Umeyama 1991])으로 좌표계를 정렬한 뒤 산출한다. 보정 전후 전체 정확도 비교에 사용한다. 정의: $\text{ATE} = \sqrt{\frac{1}{N}\sum_{i=1}^{N}\|\mathbf{p}_i^{\text{est}} - \mathbf{p}_i^{\text{GT}}\|^2}$. 상세: [12-core-drift-validation.md §I-5.5] 참조.

---

**conformal gate (컨포멀 게이트)**
Conformal prediction(CP) [Vovk 2005] 기반의 측정값 기각 게이트. 캘리브레이션 세트의 nonconformity score 경험적 분위수를 임계값으로 사용하여, 가정 분포 없이 커버리지 보장을 유지하면서 이상 측정값(outlier)을 기각한다. 본 시스템에서는 `ConformalGate` 클래스가 VPS spatial gate 및 PF predict σ 결정에 배선 예정이며, 현재 `absFixGateSigma = 5.0` 상수가 그 역할을 임시 대행한다. 참고: inductive CP는 [Vovk 2005] §5.3.

---

**EqNIO (Equivariant Neural Inertial Odometry)**
O(2) 등변(equivariant) 대칭성을 이용한 신경 관성 오도메트리 모델 [Jayanth 2025]. IMU 프레임 수평 회전에 대해 예측 결과가 올바르게 변환되도록 보장하는 기저 전처리(EqO2Preprocess)를 사용한다. 윈도우 200 샘플(200 Hz → 1 s) IMU를 입력으로 받아 보행 변위 `[vx, vy]`를 출력한다. 현 버전(`eqnio_o2.onnx`)은 per-step 공분산 헤드를 포함하지 않는다.

---

**FP (Fingerprint / 핑거프린트)**
BLE RSSI, WiFi RSSI, 자기장 세기 등 장소 고유의 신호 패턴을 사전 수집하여 위치 지도로 구성하고, 라이브 측정값과 매칭해 위치를 추정하는 방식. 본 시스템에서는 자기장 fingerprint(`MagReference`, GP 자기 지도)가 구현되어 있으며 BLE/WiFi FP는 green-field 상태이다.

---

**GT (Ground Truth / 진실값)**
위치·헤딩 추정값의 정확도를 평가하기 위한 기준 위치. 본 프로젝트에서는 ARKit/ARCore VIO 포즈, VPS hold-out PnP 결과, 도면 N점 앵커(상사변환 정합)를 GT로 사용한다. 절대 GT(토탈스테이션, 레이저 기준점)는 미측정 상태이다.

---

**hloc (Hierarchical Localization)**
전역 검색(NetVLAD retrieval)과 지역 매칭(SuperPoint + LightGlue)을 계층적으로 결합하는 시각 측위 프레임워크 [Sarlin 2019]. 쿼리와 유사한 데이터베이스 이미지를 먼저 고른 뒤 그 이미지와만 지역 매칭을 수행하여 계산량을 줄인다. GitHub: https://github.com/cvg/Hierarchical-Localization.

---

**NEES (Normalized Estimation Error Squared)**
추정 오차를 추정 공분산으로 정규화한 일관성(consistency) 지표. $\text{NEES} = \mathbf{e}^T \mathbf{P}^{-1} \mathbf{e}$. 이상적으로는 상태 차원수 d에 가까운 값을 가져야 하며(기댓값 = d), NEES ≫ d이면 공분산이 과소 추정(overconfident), NEES ≪ d이면 과대 추정임을 나타낸다. EqNIO 누적 공분산 NEES는 현재 측정 예정이다.

---

**NetVLAD**
VLAD(Vector of Locally Aggregated Descriptors)를 CNN 레이어로 미분 가능하게 구현한 전역 장소 인식 디스크립터 [Arandjelović 2016]. 쿼리 이미지와 데이터베이스 이미지 간 장소 유사도를 빠르게 계산하여 top-K 후보를 검색하는 데 사용한다. 본 시스템 VPS 파이프라인에서 top-20 retrieval을 담당한다.

---

**OOSM (Out-of-Sequence Measurement / 순서 외 측정)**
측정 발생 시각보다 늦게 도착하는 측정값. VPS 파이프라인은 셔터 시각(t_photo) 이후 네트워크 왕복 + 추론 시간으로 인해 ~수 초~20 s 지연으로 fix가 도착한다. 이를 도착 시각에 주입하면 입자 분포와 VPS 정밀도 간 불일치로 N_eff가 붕괴한다. Bar-Shalom [Bar-Shalom 2002]의 B-l1 알고리즘 등 OOSM 처리 기법으로 측정 시각 기준 앵커가 필요하다. 현 구현은 헤딩 역추정만 셔터시각에 적용하는 부분 OOSM 처리 상태이다.

---

**particle filter (PF, 입자 필터)**
비선형·비가우시안 사후 분포를 몬테카를로 샘플(입자)로 근사하는 순차 베이즈 필터 [Arulampalam 2002]. 각 입자는 가설 상태 `(x, y, θ, K)`를 나타내며 DR predict → measurement update → SIR resample 루프를 반복한다. 2000개 입자가 복도 대칭 모호성 등 다중 가설을 표현한다.

---

**PnP (Perspective-n-Point)**
2D 이미지 점과 3D 세계 점의 대응 관계에서 카메라의 6-DoF pose (회전 R, 이동 t)를 추정하는 알고리즘 계열. VPS 파이프라인에서 LightGlue 매칭으로 얻은 2D-3D 대응점에 RANSAC PnP(`pycolmap`, max_error=12 px)를 적용하여 `{x, y, thetaRad, sigmaM}`를 산출한다.

---

**retrodiction (역추정)**
현재 시각보다 과거 시각의 상태를 추정하는 역방향 추론. 본 시스템에서는 VPS fix 도착 시 `yawGAt(fix.tNs)`로 셔터시각 yaw를 링버퍼에서 역추정하여 헤딩 리셋의 타임스탬프 오차를 제거한다 ([Bar-Shalom 2002] 원칙의 헤딩 차원 한정 적용).

---

**RTE (Relative Trajectory Error)**
길이 d인 서브트랙에서 추정 궤적과 GT 궤적의 상대 변위 오차 RMSE. 단기 DR 정밀도(거리 의존 드리프트율)를 측정하며 절대보정과 독립적으로 DR 성능을 평가한다. 강한 드리프트 경계화 달성 시 ROCIP에서 RTE ≈ ATE가 성립한다. 정의: [12-core-drift-validation.md §I-5.5] 참조.

---

**VPS (Visual Positioning System / 시각 측위 시스템)**
카메라 이미지를 사전 구축된 시각 지도와 매칭하여 절대 6-DoF pose를 추정하는 시스템. 본 시스템의 VPS는 hloc (SuperPoint + NetVLAD + LightGlue) + COLMAP PnP 파이프라인으로 구현되며, 셔터 시각에 앵커된 위치·헤딩 fix를 파티클 필터에 주입한다. VPS만이 헤딩(yaw) 드리프트를 직접 리셋할 수 있는 절대 fix 소스이다.

---

**walkable manifold (이동 가능 영역 다양체)**
보행자가 실제로 이동할 수 있는 공간 영역. 벽, 장애물, 미서베이 영역을 제외한 도보 가능 구역. 본 시스템에서는 `CoverageMask`(서베이 커버리지 ± 버퍼 ∪ navigable 폴리곤)와 `WallMap`(벽 선분 교차 감지, HARD/SOFT/OFF 모드)으로 정의되며, 입자 필터 predict 단계에서 벽 밖 입자를 기각(`w[i] = 0.0`)하거나 감쇄(`w[i] *= 0.1`)한다.
