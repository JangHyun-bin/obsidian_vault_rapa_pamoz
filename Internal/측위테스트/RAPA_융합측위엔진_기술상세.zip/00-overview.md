# 00. 개요 — RAPA 실내 측위 기술 방법론

> **버전** v0.1-draft · **날짜** 2026-06-25 · **상태** 초안
> 이 파일(Part 0)은 전체 방법론 문서의 진입점이다. 이후 파일(10–90)이 참조하는 시스템 파이프라인 정의와 핵심 설계 원칙을 확립한다.
> 표기·인용 규약은 [README.md](./README.md) 참조. 수식·파라미터 상세는 [90-appendix.md](./90-appendix.md) 참조.

---

## 0.1 문제 정의 & 설계 목표

### 실내 측위 문제

실내 환경에서는 GPS 신호가 차단되므로 보행자 위치를 연속적으로 추정하려면 관성 센서(IMU), 카메라, BLE 비콘 등 복수의 불완전한 신호를 융합해야 한다. 이 프로젝트의 1차 타겟은 전남대학교병원 다층 건물이며, 통합 대상은 Lemon Care KMP SDK(iOS + Android)이다.

### 드리프트 경계화 (Drift Bounding)

신경 관성 추측항법(neural-inertial dead reckoning)은 누적 오차(drift)를 피할 수 없다. 핵심 설계 목표는 이 오차를 **시간에 무관하게 묶는 것**이다. 즉, 세션 길이가 늘어나도 위치 오차가 무한히 증가하지 않도록 절대 보정 신호(VPS, BLE)를 주기적으로 주입하고, 그 사이의 불확실성을 입자 필터로 표현한다. 리서치 분석([final_report_bounded-dr-delayed-fix-176ed9])에 따르면 위치 오차는 완화 가능하지만, **헤딩(yaw) 오차는 자이로 적분 결과라 유일하게 무경계이며 절대 픽스(VP 이를 리셋할 수 있다**.

### 크로스플랫폼 (Cross-platform) 목표

iOS와 Android가 동일한 KMP(Kotlin Multiplatform) `commonMain` 엔진 코어를 공유한다. 플랫폼 어댑터(SensorSource, ModelRunner, VpsLocator, BleScanner)는 얇은 레이어로 분리되어, 플랫폼별 차이(ARKit/ARCore, CoreMotion/SensorManager, ONNX Runtime 바인딩)를 엔진 코어와 격리한다.

---

## 0.2 시스템

### 파이프라인 5단계

본 시스템은 다음 5단계 파이프라인으로 구성된다.

| 단계 | 명칭 | 역할 |
|------|------|------|
| ① | 통합 캡처 (Capture) | 기기의 카메라·IMU·BLE·기압계 데이터를 동기 수집하고 서베이 이미지를 기록한다. |
| ② | VPS 맵빌드 (Map Build) | 서베이 이미지로 hloc + COLMAP + SuperPoint(특징) + NetVLAD(전역 검색) + LightGlue(매칭) 파이프라인을 통해 시각 지도를 구축한다. (상세·인용은 10-core-capture-vps.md §I-2) |
| ③ | 라이브 융합 (Live Fusion) | EqNIO 신경 관성 DR이 predict를 담당하고, 증강 파티클 필터(2000개 입자, 상태 x, y, θ, K)가 VPS·BLE·자기장 측정값을 σ-weighted measurement update로 통합한다. |
| ④ | 드리프트 보정 (Drift Correction) | VPS가 헤딩 θ를 리셋하고 지연 픽스를 셔터시각(t_photo)에 앵커하여 사후 보정을 수행한다. |
| ⑤ | 출력 (Output) | conformal gate가 불확실성을 검사 후 GUIDE(블루닷 표시) 또는 HOLD를 결정한다. 3모드 상태기계(COLD_START → TRACKING → RE_ACQUIRE)가 오케스트레이션한다. |

```mermaid
flowchart LR
    A[Capture] --> B["Map Build (VPS)"]
    B --> C["Live Fusion (EqNIO + PF)"]
    C --> D["Drift Correction"]
    D --> E[Output]
```
> 그림: 5단계 파이프라인 — 캡처부터 출력까지의 전체 흐름.

---

## 0.3 핵심 설계 원칙

### 원칙 ① 절대보정 + 신경 관성 DR + 입자 필터 결합

**VPS(주력), BLE(근접 폴백), 자기장(저가중 폴백)** 세 가지 절대보정 신호를 모두 **파티클 필터 measurement update 단일 경로(σ-weighted)로 통합**하며, 신경 관성 DR(EqNIO)이 연속 predict를 담당한다. 입자 수 2000개는 복도 대칭 모호성 같은 다중 가설(multimodal posterior)을 표현하는 최소 요건이다. 도면 제약(wall-rejection, backtracking PF)은 σ-update와 별개 경로로 운용된다.

### 원칙 ② 헤딩(yaw)이 유일한 무경계 오차 — 절대 fix만 보정 가능

EqNIO의 등변 공분산(equivariant covariance)은 변위(displacement)에만 정의되며 yaw 불확실성을 출력하지 않는다. 스마트폰 MEMS 자이로의 드리프트 속도는 ~4.5 deg/min이며, 보정 없이 방치하면 보행 거리에 비례해 수십 미터의 측방 오차가 누적된다. **BLE는 헤딩 정보가 없어 cadence를 연장할 수 없으며, 절대 픽스(VPS PnP 6-DoF pose)만이 θ를 리셋할 수 있다** [final_report_bounded-dr-delayed-fix-176ed9]. 결정 로그(2026-06-15)에서 이를 설계 원칙으로 확정하였다.

### 원칙 ③ 지연 fix는 셔터시각(t_photo)에 앵커

VPS 파이프라인(hloc 검색 + 특징 매칭 + PnP)은 네트워크 왕복 및 연산 지연으로 인해 현재 실 측정 기준 ~20 s의 지연이 발생한다. 이 fix를 도착 시각에 단순 주입하면 파티클 분포와 VPS 정밀도 간 σ 불일치로 N_eff가 붕괴한다. **올바른 방식은 셔터 시각(t_photo)을 키로 하는 링 버퍼(ring buffer)에 상태 스냅샷을 저장하고, fix 도착 시 해당 시점으로 앵커하는 것이다.** 구현에서는 `onVpsFix()` 호출 시 t_photo를 전달하는 방식으로 반영되었다(커밋 `363cdc5`, `4f6bab8`).

### 원칙 ④ 이동 가능 영역(walkable manifold) 제약

도면 벽 선분(line-segment) 정보를 활용해 update 단계에서 벽을 통과한 입자를 기각한다(hard-kill in verified corridors). zone별 강도를 변조하여(복도: hard-kill / 반개방: soft / 개방·로비: off) phantom wall 위험을 줄이고, 입자 고갈은 backtracking PF(BPF, 3–5 step)로 복구한다. PoC 단계에서는 순수 Kotlin `commonMain` line-segment 표현을 사용하며, 양산 시 navmesh(recast4j)로 전환한다.

### 원칙 ⑤ 플랫폼 공유 엔진 + 얇은 플랫폼 어댑터

`commonMain`에 DR·PF·융합·도면 제약·PositioningEngine(`Flow<PositionEstimate>`)을 배치하고, `iosMain`/`androidMain`에는 SensorSource(CoreMotion/SensorManager), ModelRunner(ONNX Runtime 바인딩), VpsLocator(`suspend locate(image)→VpsFix?` 인터페이스) 등 얇은 어댑터만 위치시킨다. VpsLocator 인터페이스는 server-assisted 구현과 on-device 구현 간 drop-in 교체를 보장하여 Phase B → Phase C 전환 시 엔진·배선 변경이 불필요하다.

---

## 0.4 표기·데이터셋·재현성 노트

### 표기 규약

상세 표기 규약은 [README.md](./README.md)를 따른다. 요약:

- 본문은 한글, 기술 용어·논문명·수식·algorithm identifier는 영문 유지
- 인라인 인용: `[Author Year]` 형식
- 정식 참고문헌: [90-appendix.md](./90-appendix.md)
- 미측정 수치: `(측정 예정)` 표기, 추정치 금지
- 진행 상태: ✅완료 / 🔶진행중 / ⏳예정

### 기기·데이터셋

| 항목 | 값 | 상태 |
|------|-----|------|
| 캡처 기기 | iPhone 15 Pro (iPhone15,3), iOS 27 Beta | ✅ 확정 |
| 서베이 세션 | `20260623-113521` (VPS 맵빌드 기준) | ✅ 완료 |
| VPS 맵 reproj 오차 | 1.67 px (중앙값) | ✅ 측정 완료 |
| VPS hold-out 중앙값 | 7.6 cm | ✅ 측정 완료 |
| 병원 파일럿 데이터셋 | 전남대학교병원 다층 환경 | ⏳ 수집 예정 |
| 정밀 ATE 벤치마크 (융합) | — | (측정 예정) |
| 헤딩 드리프트 속도 (실기기) | — | (측정 예정) |
| EqNIO 누적 공분산 NEES | — | (측정 예정) |

### 파라미터 참조

파티클 수(2000), EqNIO 공분산 인플레이션 계수 α, σ 채널별 설정(`measSigmaPerCh`), conformal gate 임계값, BPF 스텝 수(3–5) 등 수치 파라미터는 [90-appendix.md](./90-appendix.md)에서 정의하며, 이 파일에서는 그 설계 근거만 설명한다.

### 재현성

- VPS 맵빌드 스크립트: `vps/` 디렉터리 내 `arkit_to_colmap` → `build_map(hloc)` → `localize` 파이프라인
- iOS 캡처 앱: KMP SDK `iosMain` + RapaCapture, Xcode-beta 27.0, 팀 M9QXG9P6HU
- 실험 로그 및 결과 시각화: `vps/results/`
- 재현 체크리스트 상세: [90-appendix.md](./90-appendix.md)
