# I-4 / I-5. 드리프트 보정 레이어 & 검증 방법론

> **버전** v0.1-draft · **날짜** 2026-06-25 · **상태** 🔶 진행 중(I-4) / ✅ 확정(I-5 프로토콜)
> 본 파일(Part I-4 / I-5)은 Part I 공통 코어의 드리프트 보정 레이어와 그 검증 방법론을 기술한다. `20-platform-android.md`·`21-platform-ios.md`·`30-compare-converge.md` 파일이 드리프트 보정 구성요소 및 검증 프로토콜을 참조한다. 코드 검증 출처:
> - `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/map/HeadingOffsetMap.kt`
> - `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/mag/MagneticLocator.kt`
> - `tools/build_heading_offset.py` · `tools/mag_repeatability.py`
> - `vps/test_parity.py`
> - `docs/superpowers/specs/2026-06-24-drift-correction-methodology-design.md`
> - `research/notes/final_report_bounded-dr-delayed-fix-176ed9.md`

---

## I-4 드리프트 보정 레이어 (🔶 진행 중)

### I-4.1 배경 — 드리프트의 근본 구조

EqNIO O(2) 관성 DR은 변위 `[vx, vy]`만 출력하고 **헤딩(yaw) 불확실성은 출력하지 않는다.** 스마트폰 MEMS 자이로의 드리프트 속도는 ~4.5 deg/min이며, 보정 없이 방치하면 보행 거리에 비례해 측방 오차가 누적된다(기기 실측 증상: 궤적이 도면에서 점점 어긋나는 곡선). 이는 위치 오차와 달리 **헤딩 드리프트가 지배하는 경우**로, 수 분 보행 시 10~50 m급 측방 오차로 비화된다 [final_report_bounded-dr-delayed-fix-176ed9]. 설계 원칙은 **주기적 절대보정(re-anchoring)** 으로 이를 경계화(bounded-error)하는 것이다.

![Re-anchor interval vs tail position error: 3 drift rate lines (0.4, 1.0, 1.5 m/min), baseline 2.7 m, design ceiling shaded at 90–120 s](./figures/drift_budget.png)
> 그림: VPS 재앵커 간격과 기대 꼬리 위치오차의 관계 — **예시 곡선(ILLUSTRATIVE)**. 실측 DR 드리프트율 범위(0.4–1.5 m/min)를 기반으로 작성. 가로축: 재앵커 간격(s), 세로축: 간격 말단 기대 누적오차(m). 회색 점선은 신경 DR 기준 ATE 2.7 m; 녹색 음영은 설계 목표 구간(90–120 s). 실제 기기 환경에서는 DR 모드·보행속도·도면 제약에 따라 달라진다.

현재 파티클 필터 엔진은 두 가지 재앵커 인터페이스를 이미 구비한다.

- `onVpsFix()` → `applyGatedFix(위치)` + `resetHeading(헤딩 직접 리셋)` (VPS 전용)
- `onAbsolutePosition(x, y, σ, t)` → 위치 전용 update (자기장·BLE 유도 위치)

따라서 드리프트 보정은 **배선과 보정원 선택**이 핵심이며, 엔진은 이를 흡수할 준비가 되어 있다.

---

### I-4.2 보정 구성요소 (5종)

#### ① 주기적 절대보정 — VPS 재앵커 (✅ 완료 + 진행 중)

VPS `onVpsFix()` 경로에서 `resetHeading(fix.thetaRad − lastYawG, vpsHeadingResetSpreadRad=5°)`를 실행해 DR yaw 드리프트를 일시에 제거한다. 콜드스타트(L0+L1)는 완료되었으며, 비콜드스타트 재앵커 캐던스 설계(90–120 s, 헤딩 드리프트 결정)는 진행 중이다.

**설계 근거**: 헤딩은 EqNIO의 등변 공분산 범위 밖이며 유일한 무경계 오차 모드다. 위치만 보정하는 BLE·자기장 픽스는 헤딩을 직접 리셋할 수 없으므로 VPS가 헤딩 보정의 유일한 수단이다 [final_report_bounded-dr-delayed-fix-176ed9].

#### ② 자기 트랙 — MagneticLocator 시퀀스 매처 (🔶 진행 중)

카메라 없이 위치 보정을 제공하는 `camera-free` 보조 보정원이다.

`MagneticLocator.kt`는 엔진 추정 위치와 라이브 `|wm|`(자기장 세기) 샘플을 순차 수신하여, 복도 참조 프로파일 `MagReference`에 **슬라이딩 윈도우 시퀀스 매칭**으로 비교한다. 윈도우를 엔진 상대 좌표로 구성하므로 DR 절대 오프셋이 상쇄되어 드리프트에 강인하다.

```kotlin
// MagneticLocator.kt (핵심 로직 요약)
val rel = DoubleArray(n) { bufS.elementAt(it) - s }   // ≤0 (과거 상대 s)
// 참조 프로파일에 rel[] 오프셋으로 슬라이딩 → RMS 최소 후보 bestS
if (sqrt(bestCost) > gateUt) return null   // RMS > 5 µT → 기각
return AbsFix(fx, fy, sigmaM=0.6, tNs)     // onAbsolutePosition으로 전달
```

파라미터: 윈도우 3.0 m · 최소 누적이동 2.0 m · RMS 게이트 5 µT · 픽스 σ=0.6 m · 방출 간격 0.5 m. 픽스는 `onAbsolutePosition(x, y, 0.6, tNs)`으로 PF에 주입되며 위치 우도 update를 수행한다(헤딩 리셋 없음; 복도에서는 위치 픽스가 입자 분포를 복도 선에 간접 교정하는 효과).

**실증**: 2026-06-24 tools/mag_localize_test.py (pass1→pass2 cross-day, iPhone15,3) — 단일 `|wm|` 점 매칭 중앙 1.72 m(앨리어싱) 대비 **시퀀스 매칭(≥3 m window) 중앙 0.20 m · 90%ile 0.56 m · 90% <1 m.** 학습 0짜리 템플릿 매칭만으로 ~0.2 m 달성. 시퀀스 윈도우가 핵심임을 확인했으며, `MagneticLocator`의 설계 전제를 실증 [2026-06-24-drift-correction-methodology-design].

#### ③ 이동 가능 영역 제약 — CoverageMask + WallMap (🔶 진행 중)

보정 신호가 없는 구간에도 입자 분포가 도면 밖으로 이탈하지 않도록 묶는 **구조적 드리프트 경계화**다.

- `CoverageMask`: 서베이된 복도 경로 ± 버퍼 ∪ 도면 navigable 폴리곤 안에서만 입자를 허용(`w[i] = 0.0`). 드리프트가 벽 너머로 이탈하는 것을 원천 차단.
- `WallMap`: 복도 구역에서 hard-kill (이동 선분이 벽 교차 시 `w[i] = 0.0`), 반개방 soft (`w[i] *= 0.1`). 벽이 가로방향을 bound해 복도 측방 오차를 억제.

이 두 제약만으로도 자기 빌드 전 순수 DR의 드리프트를 즉시 클립하는 싼 즉효 보정이다. 현재 서베이 `20260623-113521`로 커버리지 67 m²(도면 29%) 확인됨.

#### ④ 자북 오프셋 시드 — HeadingOffsetMap (✅ 완료)

콜드스타트 시 VPS-PnP 헤딩의 노이즈를 줄이기 위한 사전 정보다.

`HeadingOffsetMap.kt`는 `offset(x,y) = map_heading − magNorth_heading (rad, 맵 프레임)`을 격자(row-major grid)에 저장하고, `at(x, y)`로 임의 위치의 오프셋을 반환한다. 미커버 셀·bbox 밖은 전체 원형평균(constant 폴백)을 사용해 항상 유효값을 반환한다.

`build_heading_offset.py`가 서베이 imulog의 자북 attitude(`r`)와 GT pose(`p`)에서 `mapHeading − magNorth`를 계산해 격자 JSON을 생성한다. sanity 게이트: 오프셋 원형 표준편차 > 25 deg이면 `FRAME SANITY FAIL`로 종료. 콜드스타트 PF_θ 시드를 단일샷 VPS-PnP 헤딩 대신 `자북 + HeadingOffsetMap.at(x,y)`에서 얻어 드리프트 초기조건을 개선한다.

#### ⑤ 카메라-프리 자기측위 파이프라인 (🔶 검증 단계)

②의 `MagneticLocator`에 데이터를 공급하는 참조 프로파일 빌드 + 자기 라이브 배선 전체 파이프라인이다. 복도 중심선(PCA축) + `|wm|(s)` 참조 프로파일(`MagReference.kt`) 빌드 → live `|wm|` 수신(현재 `.xArbitraryZVertical` ARKit 세션에서 자기 미수신; 라이브 배선 추가 필요) → `MagneticLocator.onSample()` → `onAbsolutePosition()` 주입. 라이브 배선 미완료가 현재 유일한 미구현 항목이다.

---

### I-4.3 실증 결과

| 검증 단계 | 측정 | 결과 | 출처 |
|---|---|---|---|
| Step-1 반복성 게이트 (세션 내) | 재방문 SNR | **6.3** (반복성 2.1 µT vs 신호 13.4 µT) | `tools/mag_repeatability.py`, 2026-06-23 |
| Step-1 cross-day 게이트 | 복도 주축 프로파일 상관 / Δ\|wm\| | **상관 0.98** / **1.6 µT** ≪ 신호 13.4 µT → **GO** | `tools/mag_repeatability.py`, pass1 06-23 vs pass2 06-24 |
| Step-2 개념 증명 | 시퀀스 매칭 복도 위치오차 | 중앙 **0.20 m**, 90%ile **0.56 m** | `tools/mag_localize_test.py`, 2026-06-24 |

> **정합 주의**: 두 survey는 각자 ARKit 세션(다른 좌표계)이므로, `mag_repeatability.py`의 `cross_pass_aligned()`가 PCA 주축 + flip/lag 탐색으로 1D 정합 후 비교한다.

> **남은 게이트**: cross-device(Android S22 패스 미수집). 1D(복도축) 검증 완료 — 2D(폭) 및 cross-device는 추가 데이터 캠페인 필요.

---

### I-4.4 한계 명시 (중요)

**① 자기 보정 기여 ~0 (cross-core 실측)**: iOS 캡처→실엔진 cross-core 융합 결과에서 자기 보정의 위치 개선 기여도는 현재 **~0**으로 측정되었다. 이는 Android 플랫폼에서도 공통으로 관찰되었다. 원인은 실내 자기 왜곡(금속 구조물·전기 설비)으로 인한 지도-측정 불일치 및 현행 `measSigmaPerCh = [1e6, 4.0]` 보수적 설정으로 추정된다. 본 파이프라인의 `MagneticLocator` 기반 보정은 Step-1/2 검증을 통과했으나 **라이브 융합에서 즉각적 성능 개선을 보장하지 않는다.** 학습 기반 자기지문 측위 [Guo 2025] 같은 대안이 있으나, 이는 GP 우도 역할(시퀀스 매칭 → PF 위치 update)과는 별개 접근이며 본 시스템의 환경 의존 한계를 직접 해소하지 않는다.

**② 헤딩 무경계 (EqNIO 공분산 변위 전용)**: EqNIO의 등변 공분산은 변위에만 정의되며 yaw 불확실성을 출력하지 않는다. 자기장 `onAbsolutePosition` 픽스는 위치만 업데이트하고 헤딩을 직접 리셋하지 않으므로, **헤딩 드리프트는 자기 보정만으로는 경계화할 수 없다.** 헤딩 리셋은 VPS `resetHeading()` 경로만 가능하다 [final_report_bounded-dr-delayed-fix-176ed9].

**③ 자기 환경 의존 (단독 의존 지양)**: 자기 바코드의 SNR·반복성은 환경(금속 구조물, 전기 설비, 가구 배치 변경)에 따라 크게 달라지며, 시간적 staleness 위험이 있다. cross-device 이질성(기기별 자력계 특성 차이)도 미해결 과제다. 따라서 자기 측위는 **VPS 재앵커·WallMap과 병행하는 보조 보정원**으로 운용해야 하며, 단독 의존은 지양한다. ConformalGate가 나쁜 자기 픽스를 기각하고 DR/VPS fallback을 유지한다.

---

## I-5 검증 방법론

### I-5.1 GT 앵커 정확도 측정 절차 — N점 상사변환

**목적**: 엔진 추정 궤적과 실제 도면 GT 위치 간의 절대 오차(ATE)를 측정하기 위해 좌표계 정합을 수행한다.

**절차**:

1. **GT 앵커 선정**: 도면 상에서 정확히 식별 가능한 N개 지점(복도 교차점, 문 중앙, 벽 모서리 등)을 선정한다. 권장 N ≥ 6; 복도형 경로에서는 경로 양 끝 + 중간 교차점을 포함한다.

2. **엔진 추정 좌표 수집**: 측위 세션에서 각 GT 앵커 지점을 통과하는 시각 `tᵢ`에 엔진 추정 위치 `(x̂ᵢ, ŷᵢ)`를 기록한다.

3. **2D 상사변환 추정 (Similarity Transform)**: GT 좌표 `{(xᵢ, yᵢ)}` ↔ 엔진 추정 좌표 `{(x̂ᵢ, ŷᵢ)}`를 최소제곱으로 정합한다:

   ```
   [x_aligned]   = s · R(φ) · [x̂] + [tx]
   [y_aligned]               [ŷ]   [ty]
   ```

   파라미터: 스케일 `s`, 회전 `φ`, 평행이동 `(tx, ty)`. Umeyama 알고리즘 [Umeyama 1991]이 표준 구현이다.

4. **ATE / RTE 산출**: §I-5.5 정의 참조. 전체 궤적 오차를 상사변환 후 GT 대비 RMSE로 산출한다.

**실측 프로토콜**: 현재 서베이 `20260623-113521` (복도형 14 m × 3.5 m, iPhone15,3)에서 VPS hold-out 중앙값 7.6 cm, reproj 오차 중앙값 1.67 px를 기준 맵 정확도로 확인. 융합 ATE 벤치마크는 **(측정 예정)**.

---

### I-5.2 A-B-A 테스트 — 헤딩 vs. 스케일 드리프트 분해

```mermaid
flowchart LR
    A["A (start)"] --> W1["walk"]
    W1 --> B["B (180 turn)"]
    B --> W2["walk back"]
    W2 --> AP["A' (return)"]
    AP --> ERR["A' - A = closing error"]
    ERR --> D["decompose: heading vs scale"]
```
> 그림: A-B-A 테스트와 오차 분해 — 복귀 오차 벡터를 헤딩·스케일 성분으로 분리.

**목적**: A-B-A(출발점 → 목적지 → 출발점 복귀) 테스트로 드리프트의 원인 성분을 정량 분리한다.

**원리**: A→B→A 완전 왕복 시 이상적으로는 복귀 오차가 0이어야 하나, 실제 궤적에서는 복귀 오차가 발생한다. 이 복귀 오차의 방향과 크기로 지배 성분을 구분한다:

- **헤딩 드리프트 지배**: B 지점에서 180° 방향전환(U-turn) 시 헤딩 오차가 두 배로 증폭된다. A→B 구간 누적 헤딩 오차 `Δθ`는 B→A 구간에서 반대 방향으로 동일하게 누적되어 복귀 오차 ≈ `2 · L · sin(Δθ)`(L = A-B 거리). 궤적이 측방으로 휘어지는 '곡선' 형태가 특징이다.
- **스케일(보폭) 오차 지배**: 복귀 오차가 출발-복귀 방향 축을 따른다(종방향 오차). 180° 반환 후 스케일 오차가 부호가 반대로 누적되어 상쇄되므로, 스케일 오차는 **A-B-A에서 헤딩 오차에 비해 상쇄 효과가 크다.**

**실용 분해 공식**: 복귀 오차 벡터를 A-B 방향(종축) / 수직(횡축)으로 분해한다.

| 복귀 오차 성분 | 주요 원인 |
|---|---|
| 횡(수직) 성분 지배 | 헤딩 드리프트 |
| 종(A-B 방향) 성분 지배 | 스케일/보폭 오차 |

**현 시스템 적용**: 기기 실측에서 궤적 곡선 현상이 관찰되었으며, 이는 헤딩 드리프트 지배의 A-B-A 시그니처와 일치한다. A-B-A 분석은 보정 전후 헤딩 개선량을 정량화하는 표준 벤치마크로 활용한다. 테스트 경로: 현재 복도 14 m 왕복. 권장 B 지점 = 복도 끝 명확한 반환 마커.

---

### I-5.3 VPS 검증 — Reproj 오차 & Registration

**Reprojection 오차 (VPS 맵 품질)**:

VPS 맵빌드(`hloc + COLMAP + SuperPoint + LightGlue`) 완료 후 다음 지표를 측정한다.

- **Reprojection RMSE**: SfM 재투영 잔차(픽셀). 현재 측정값: **1.67 px (중앙값)** (서베이 `20260623-113521`). 목표 < 3 px.
- **Hold-out 위치 오차**: 서베이 이미지의 hold-out 분할에서 PnP localize 결과와 GT 위치의 차이. 현재: **7.6 cm (중앙값)**.

**Registration 검증 (도면 ↔ VPS 맵 좌표계 정합)**:

VPS 맵 좌표와 도면 좌표계 간 2D 상사변환 파라미터 `(s, φ, tx, ty)`를 §I-5.1과 동일한 N점 정합으로 추정한다. 정합 잔차(registration RMSE)가 목표 내인지 확인. 현재 프로토콜: `vps/arkit_to_colmap` → `build_map(hloc)` → `localize` 파이프라인.

---

### I-5.4 Golden-Replay Parity 테스트 (test_parity.py)

**목적**: VPS 서비스 코드 변경(모델 업데이트, 리팩터링, 영속화 등) 후 기준 출력과의 일치를 자동 검증한다. 모델 영속화(요청당 재로딩 제거, 18 s → <5 s 개선) 후 parity 게이트로 회귀를 차단한다 (커밋 `a7d9c0f`).

**프로토콜 (`vps/test_parity.py`)**:

1. `vps/parity_golden.json` — 기준 이미지별 `{x, y, thetaRad, inliers}` 저장.
2. `http://127.0.0.1:8765/localize` 에 이미지 전송 → 새 결과 수신.
3. 허용 오차: `|Δx| ≤ 0.05 m`, `|Δy| ≤ 0.05 m`, `|Δθ| ≤ 0.02 rad`, `|Δinliers| ≤ 8`.
4. 지연 게이트: 지연 중앙값 < 5,000 ms.

```python
# test_parity.py 핵심 게이트
TOL = dict(x=0.05, y=0.05, theta=0.02, inl=8)
if warm > 5000: print("지연 게이트 FAIL"); sys.exit(2)
```

parity 테스트는 CI 단계에서 VPS 서비스가 구동된 상태에서 실행하며, `PARITY OK (N장 일치)` 및 `지연 게이트 OK (<5s)` 메시지로 합격을 확인한다.

---

### I-5.5 ATE / RTE 정의 및 데이터셋 비교불가성 원칙

#### ATE (Absolute Trajectory Error)

$$
\text{ATE} = \sqrt{ \frac{1}{N} \sum_{i=1}^{N} \| \mathbf{p}_i^{\text{est}} - \mathbf{p}_i^{\text{GT}} \|^2 }
$$

상사변환 정합 후 GT 궤적과 추정 궤적 간 RMSE. 장기 정확도의 전체 척도. 보정 전후 비교 및 세션 간 비교에 사용.

#### RTE (Relative Trajectory Error)

$$
\text{RTE}(d) = \sqrt{ \frac{1}{M} \sum_{j=1}^{M} \| (\mathbf{p}_{i_j+d}^{\text{est}} - \mathbf{p}_{i_j}^{\text{est}}) - (\mathbf{p}_{i_j+d}^{\text{GT}} - \mathbf{p}_{i_j}^{\text{GT}}) \|^2 }
$$

길이 `d` 서브트랙 상의 상대 변위 오차 RMSE. 단기 DR 정밀도(거리 의존 드리프트율)를 측정하며 절대보정과 독립적으로 DR 성능을 평가한다. ROCIP에서 RTE ≈ ATE(누적 없음)는 강한 드리프트 경계화의 지표다 [final_report_bounded-dr-delayed-fix-176ed9].

#### 데이터셋 비교불가성 원칙 (⚠️ 필수 준수)

논문 수치 비교 시 다음 원칙을 엄수한다.

**RoNIN, RIDI, TLIO, OxIOD, ADVIO 데이터셋은 서로 비교 불가하다.**

동일 모델도 데이터셋에 따라 ATE가 수 배 이상 차이를 보인다. 예:

| 모델 | 데이터셋 | ATE |
|---|---|---|
| GNIO | OxIOD | 0.74 m |
| GNIO | RoNIN-unseen | 5.02 m |
| EqNIO | TLIO | 1.43 m |
| EqNIO | Aria | 1.12 m |
| RoNIN-ResNet | RoNIN-unseen | 5.14 m |
| RoNIN-ResNet | OxIOD-unseen | 6.71 m |

*동일 모델의 ~7× ATE 스프레드가 데이터셋 차이만으로 발생한다* [final_report_bounded-dr-delayed-fix-176ed9].

---

## 인용

상세 참고문헌 표기는 [90-appendix.md](./90-appendix.md)를 따른다.

| 키 | 정보 |
|---|---|
| [Guo 2025] | Guo et al., "Robust Magnetic Fingerprint Positioning … Using Res-T-LSTM," *Sensors* 2025, 25, 7464 |
| [Umeyama 1991] | Umeyama, "Least-Squares Estimation of Transformation Parameters Between Two Point Patterns," *IEEE TPAMI* 1991 |
| [Solin 2018] | Solin et al., "Terrain Navigation in the Magnetic Landscape: Particle Filtering for Indoor Positioning," EUSIPCO 2018 |
| [Herath 2020] | Herath et al., "RoNIN: Robust Neural Inertial Navigation in the Wild," ICRA 2020 |
| [Liu 2020] | Liu et al., "TLIO: Tight Learned Inertial Odometry," RA-L 2020 |
| [Jayanth 2025] | Jayanth et al., "EqNIO: Equivariant Neural Inertial Odometry" (preprint under review) |
| [final_report_bounded-dr-delayed-fix-176ed9] | 내부 리서치 노트 — ATE/RTE 정의, 데이터셋 비교불가성, A-B-A 헤딩 분해, 헤딩 무경계 원칙 (2026-06-24) |
| [2026-06-24-drift-correction-methodology-design] | 내부 스펙 — 자기 fingerprint 드리프트 보정 방법론 설계, Step-1/2 검증 결과 (2026-06-24) |
