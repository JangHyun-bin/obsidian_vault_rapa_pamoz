# II-A. 플랫폼 프로파일 — Android

> **버전** v0.1-draft · **날짜** 2026-06-25 · **상태** 초안
> 이 파일(Part II-A)은 Android 플랫폼에 특화된 센서 스택, 핑거프린팅(FP) 수집, 보정·GT 방법론, 현재까지의 실측 결과를 기록한다. 플랫폼 간 비교는 [30-compare-converge.md](./30-compare-converge.md) 참조.
> 코어 공통 알고리즘(EqNIO, 입자 필터, 라이브 융합 엔진)은 [11-core-fusion.md](./11-core-fusion.md) (Part I-3)에 있으며, 본 파일은 Android-고유 레이어만 기술한다.
>
> 코드 검증 출처:
> - `core-positioning/src/androidMain/kotlin/com/rapa/indoorpos/core/source/SensorManagerSource.kt`
> - `indoorpos-android/android-app/src/main/kotlin/com/rapa/indoorpos/app/sensor/SensorManagerSource.kt`
> - `indoorpos-android/android-app/src/main/kotlin/com/rapa/indoorpos/app/survey/ArcoreSurveyRecorder.kt`
> - `indoorpos-android/android-app/src/main/kotlin/com/rapa/indoorpos/app/survey/SurveyViewModel.kt`
> - `core-positioning/src/androidMain/kotlin/com/rapa/indoorpos/core/map/AndroidMapLoader.kt`
> - `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/api/DefaultPositioningSession.kt`

---

## II-A.1 센서 스택

코어 공통부는 I-3 참조.

### 회전 소스 — TYPE_GAME_ROTATION_VECTOR (자력계 제외)

Android SensorManager 기반 어댑터(`SensorManagerSource.kt`)는 회전 소스로 **`TYPE_GAME_ROTATION_VECTOR`를 사용한다(자력계 제외)**. 이것이 iOS와의 핵심 차이다.

```kotlin
// core-positioning/src/androidMain/kotlin/.../source/SensorManagerSource.kt, L22, L73-76
private val gameRotVec = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
...
Sensor.TYPE_GAME_ROTATION_VECTOR -> {
    SensorManager.getRotationMatrixFromVector(gameRotMatrix, e.values)
    gameRotCb?.invoke(e.timestamp, gameRotMatrix.copyOf())
}
```

`TYPE_GAME_ROTATION_VECTOR`는 가속도계 + 자이로스코프만으로 자세를 추정하는 Android가상 센서로, 자력계(magnetometer)를 융합하지 않는다. 따라서 **절대 방위(북쪽 기준)를 알 수 없으며** 자기 간섭에 완전히 독립적이다. 이는 iOS가 CoreMotion의 `.xMagneticNorthZVertical`(자력계 융합 attitude) 기반으로 절대 방위를 포함하는 것과 대비된다 (→ II-B, 30-compare 참조).

또한 `TYPE_ROTATION_VECTOR`(자력계 포함 절대 방위)도 동시에 등록하여 `setAbsRotationListener` 콜백으로 노출하나, 현재 EqNIO DR 파이프라인(`DefaultPositioningSession.kt`)은 `setGameRotationListener` 콜백 — 즉 `TYPE_GAME_ROTATION_VECTOR` — 만 엔진에 연결한다. `TYPE_ROTATION_VECTOR`는 survey 로그(`ImuLogRecorder`, `rv` 라인)에 기록되지만 실시간 DR 경로에는 사용되지 않는다.

### 가속도계·자이로스코프 레이트

두 센서 모두 `SENSOR_DELAY_FASTEST`로 등록된다 (L45-46 코어 버전, L42-43 앱 버전):

```kotlin
// core-positioning/src/androidMain/.../source/SensorManagerSource.kt, L45-46
accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST, handler) }
gyroUncal?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST, handler) }
```

`SENSOR_DELAY_FASTEST`는 Android SensorManager의 가장 빠른 전달 모드로 기기별·SoC별로 실제 레이트가 다르나 일반적으로 **200 Hz 이상**이다. 라이브 융합 파이프라인의 리샘플러(`GravityAlignedResampler`)는 200 Hz 그리드(DT_NS = 5,000,000 ns)로 균일 리샘플링하므로, 센서 출력 레이트가 200 Hz 이상이면 정보 손실 없이 리샘플링된다.

중력(`TYPE_GRAVITY`), 보정 자기장(`TYPE_MAGNETIC_FIELD`), 절대 회전(`TYPE_ROTATION_VECTOR`), 게임 회전(`TYPE_GAME_ROTATION_VECTOR`)은 `SENSOR_DELAY_GAME`(50 Hz 기준, 20 ms)으로 등록된다 (L48-51).

### 자이로스코프 — TYPE_GYROSCOPE_UNCALIBRATED

자이로스코프는 `TYPE_GYROSCOPE_UNCALIBRATED`를 사용하여 OS 드리프트 보정 전 원시 각속도를 수집한다 (L17, L58-59). ImuSample은 gyroUncal 이벤트 시 직전 accel 스냅샷과 결합하여 방출된다. 이는 iOS와 동일하게 원시 IMU를 선호하는 설계이며, 모델 입력 전처리 파이프라인이 센서 레벨의 보정을 기대하지 않음을 의미한다.

### 자기장 (사이드 채널)

자기장은 `TYPE_MAGNETIC_FIELD_UNCALIBRATED`(바이어스 포함 원시)와 `TYPE_MAGNETIC_FIELD`(OS 보정) 두 채널을 모두 수집한다 (L18, L20). survey 기록(`ArcoreSurveyRecorder`)에서는 보정 자기장(`calMag`)을 회전 행렬로 월드 프레임으로 변환하여 `wmx/wmy/wmz`로 저장한다. 이는 자기 지도(`GpMagneticMap`) 학습 입력에 사용된다.

---

## II-A.2 FP (BLE/WiFi) 지원

코어 공통부는 I-3 참조.

### 자기장 핑거프린팅 (플랫폼 공통)

자기장 서베이 수집은 Android에서 `ArcoreSurveyRecorder`가 담당한다. ARCore 포즈(x, z 바닥 평면 좌표)를 GT로 삼아 자기장 측정값과 타임스탬프를 결합한 `SurveyRecord` JSONL을 생성한다. 이를 `tools/gp_fit.py`로 처리하면 GP(Gaussian Process) 자기 지도(`GpMagneticMap`)가 생성된다.

### BLE / WiFi 서베이 (플랫폼 고유 — 현황: 미구현)

**indoorpos-android 코드베이스를 전수 조사한 결과, BLE 스캔(`BluetoothLeScanner`) 및 WiFi 스캔(`WifiManager`) 관련 코드가 존재하지 않는다.** 현재 `indoorpos-android`의 서베이 레이어는 ARCore 포즈 + 자기장 수집에 한정되어 있다. 앱 레이어 디렉터리(`ar/`, `neural/`, `sensor/`, `survey/`, `ui/`)와 `SurveyRecord` 데이터 모델 모두에 BLE/WiFi 필드가 없음을 코드에서 확인했다.

BLE 서베이 및 WiFi RSSI 핑거프린팅은 현재 **green-field 상태**이다. `DefaultPositioningSession.kt`는 `onAbsolutePosition(x, y, sigmaM, tNs)` API를 통해 외부에서 BLE 근접 위치를 주입받는 인터페이스를 이미 갖추고 있으나, 앱 레이어의 BLE 스캔·매칭 구현은 존재하지 않는다.

이는 iOS와 마찬가지로 현재 두 플랫폼 모두 BLE/WiFi 서베이가 구현되지 않았음을 의미한다. BLE·WiFi 지원은 향후 Android 플랫폼에 우선적으로 추가될 것으로 예정되며(비교 매트릭스 → 30-compare §3 참조), OS 레벨의 BLE·WiFi API는 Android가 더 개방적이다.

---

## II-A.3 보정·GT (ARCore 재측위)

코어 공통부는 I-3 참조.

### ARCore 재측위 GT 앵커

`ArcoreSurveyRecorder`는 ARCore `TrackingState.TRACKING` 상태에서만 `Frame.camera.pose`의 translation `[x, y, z]`를 수집한다 (L34-37). 평면 측위 규약에 따라 ARCore 좌표계의 (x, z) 성분을 바닥 평면 좌표 (x, y)로 사용하며, 중력이 ARCore의 y축에 정렬된다 (L48 주석):

```kotlin
// ArcoreSurveyRecorder.kt, L48
val rec = SurveyRecord(t = mag.t, x = p[0].toDouble(), y = p[2].toDouble(), ...)
```

ARCore는 세션 내에서 시각적 오도메트리와 IMU를 결합한 VIO(Visual-Inertial Odometry) 기반으로 상대 포즈를 추정하며, 세션 시작점을 원점으로 하는 로컬 좌표계를 사용한다. 복수 서베이 세션을 정합하려면 N점 상사변환(similarity transform, 스케일·회전·이동)으로 좌표계를 정렬해야 하며 이는 `tools/` 레이어(Python)에서 수행된다.

### 자기맵 연결 여부

Android `core-positioning` 레이어에는 `AndroidMapLoader.kt`가 `loadBundledMagMap()` 함수를 제공한다:

```kotlin
// core-positioning/src/androidMain/.../map/AndroidMapLoader.kt, L10-13
fun loadBundledMagMap(context: Context, asset: String = "mag_map.json"): MapStore? = try {
    context.assets.open(asset).use { ins ->
        GpMagneticMap.fromJsonString(ins.reader(Charsets.UTF_8).readText()).takeIf { it.isLoaded }
    }
} catch (e: Exception) { null }
```

그러나 **이 함수를 실제로 호출하는 앱 레이어 코드(`DefaultPositioningSession` 초기화 시 `map=` 인수로 전달하는 호출)는 `SH_Position_PoC` 코드베이스에 존재하지 않는다** (그렇게 설계 의도가 명시되어 있으나 실체 호출 코드 없음을 코드에서 확인). `DefaultPositioningSession.kt` 주석(L18)에는 "호스트/팩토리가 호출해 `DefaultPositioningSession(map=...)`으로 주입한다"고 명시하며, `map` 파라미터 기본값은 `NoMapStore`이다 (L29). 즉 현재 Android 앱 레이어에서 `GpMagneticMap`은 **엔진에 미연결** 상태이며, 연결을 위해 별도 팩토리/호스트 코드 작성이 필요하다.

---

## II-A.4 Android 실측

코어 공통부는 I-3 참조.

### 현황

`indoorpos-android` 레포지토리 커밋 이력과 `docs/positioning-ai-architecture/` 문서 전체를 검토한 결과, **Android 플랫폼 단독의 라이브 측위 실측 수치(ATE, RMSE 등)는 현재 기록되어 있지 않다.** 이하 항목별 상태는 다음과 같다.

| 항목 | 상태 | 출처/비고 |
|------|------|-----------|
| 신경 관성 DR (EqNIO) 단독 ATE | (측정 예정) | Android 오프라인 리플레이 테스트(`OnDeviceReplayTest.kt`)는 존재하나 실측 fixture 없음 (현재-status.md §Important caveats #2) |
| 자기 지도 + DR 융합 ATE | (측정 예정) | `FusionReplay` 하네스 구축됨, 실측 JSONL fixture 미포함 |
| VPS + DR 융합 ATE | (측정 예정) | Android VPS 클라이언트 미구현 |
| on-device ONNX 추론 지연 | ~측정됨(`OnDeviceReplayTest`) | 정확한 수치 미공개; ONNX Runtime Android 기준 (측정 예정) |
| ARCore GT 정확도 | (측정 예정) | 참조 플랫폼 의존; ARCore 내부 VIO 오차 미정량화 |

### 참고: KMP 공통 엔진 검증

공통 `core-positioning` 엔진의 신경 DR 정확도는 iOS 캡처 데이터로 크로스 코어 리플레이하여 검증된 바 있다 (MEMORY: Fusion cross-core 결과 — 신경 DR ATE 2.7 m / 5.8%, iOS 캡처→실엔진). 이 수치는 KMP 엔진 공통부의 성능 참조값으로 사용할 수 있으나, **Android 센서(TYPE_GAME_ROTATION_VECTOR, SENSOR_DELAY_FASTEST)와 Android ARCore GT 조건 하의 실측값과는 별개이다.** Android 전용 실측은 별도 진행이 필요하다. (iOS 대비 비교 → 30-compare)
