# RAPA 실내 측위 기술 방법론

| 항목 | 값 |
|------|-----|
| 버전 | v0.1-draft |
| 날짜 | 2026-06-25 |
| 상태 | 초안 |


---

## 문서 구성 (TOC)

| 파일 | 설명 |
|------|------|
| [00-overview.md](./00-overview.md) | 개요: 해결 문제·시스템 한눈에 보기·설계 원칙 |
| [10-core-capture-vps.md](./10-core-capture-vps.md) | 공통: 통합 캡처·서베이 파이프라인 + VPS 맵빌드·측위 |
| [11-core-fusion.md](./11-core-fusion.md) | 공통: 라이브 융합 엔진 (EqNIO + 입자 필터) |
| [12-core-drift-validation.md](./12-core-drift-validation.md) | 공통: 드리프트 보정 (🔶 진행 중) + 검증 방법론 |
| [20-platform-android.md](./20-platform-android.md) | 플랫폼: Android 프로파일 (ARCore·IMU·BLE) |
| [21-platform-ios.md](./21-platform-ios.md) | 플랫폼: iOS 프로파일 + 드리프트 근본 원인 분석 |
| [30-compare-converge.md](./30-compare-converge.md) | 플랫폼 비교 매트릭스 + 수렴 로드맵 |
| [90-appendix.md](./90-appendix.md) | 부록: 참고문헌·재현성 체크리스트·용어집 |

---

## 표기·인용 규약

### 인용
- **인라인 인용**: `[Author Year]` 형식 사용 (예: `[Solin 2018]`)
- **정식 표기**: `./90-appendix.md` 참고문헌 절에 APA/IEEE 형식으로 수록
- 실측 수치는 반드시 출처(실험 날짜·환경·장비)를 병기
- 비교 수치는 데이터셋·프로토콜 비교불가성 명시 (예: "공개 benchmark vs. 자체 측정" 구분)

### 진행 상태 라벨
| 라벨 | 의미 |
|------|------|
| ✅ | 완료 — 수치·결과 확정 |
| 🔶 | 진행 중 — 부분 결과 있음, 업데이트 예정 |
| ⏳ | 예정 — 아직 시작하지 않음 |

- 미측정 수치는 `(측정 예정)` 으로 표기하고 수치를 추정치로 기재하지 않음

### 언어
- **본문**: 한글 사용
- **기술 용어·논문명·수식·plot/figure 텍스트·알고리즘 식별자**: 영문 유지
- 혼용 예시: "EqNIO 기반 보행자 항법 알고리즘", "Particle Filter (입자 필터)"

### 시각 자료 자리표시
- 이미지: `〔이미지: 설명 텍스트〕`
- 영상: `〔영상: 설명 텍스트〕`
- 실제 파일 첨부 전까지는 자리표시만 기재

---