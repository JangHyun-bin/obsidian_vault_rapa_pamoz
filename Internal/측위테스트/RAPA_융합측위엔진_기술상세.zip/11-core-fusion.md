# I-3. 라이브 융합 엔진 — EqNIO + 입자 필터

> **버전** v0.1-draft · **날짜** 2026-06-25 · **상태** 초안
> 본 파일(Part I-3)은 Part I 공통 코어의 핵심이다. `20-platform-android.md`·`21-platform-ios.md` 등 플랫폼 파일이 "코어 공통부는 I-3 참조"로 가리키는 문서이다. 코드 검증 출처:
> - `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/neural/NeuralOdometry.kt`
> - `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/neural/ModelRunner.kt`
> - `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/neural/EqO2Preprocess.kt`
> - `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/neural/GravityAlignedResampler.kt`
> - `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/filter/ParticleFilter.kt`
> - `core-positioning/src/commonMain/kotlin/com/rapa/indoorpos/core/live/PositioningEngine.kt`
> - `iosApp/Sources/OrtModelRunner.swift`

---

```mermaid
flowchart LR
    IMU["IMU 200Hz"] --> GR["Gravity-aligned resampler"]
    GR --> EQ["EqNIO (predict)"]
    EQ --> PF["Particle Filter (2000)"]
    VPS["VPS fix"] --> MU["PF measurement update"]
    MAG["Magnetic GP"] --> MU
    WALL["Walkable mask"] --> MU
    MU --> OUT["PositionEstimate (Flow)"]
    PF --> MU
```
> 그림: 라이브 융합 엔진 데이터 흐름 — IMU predict 경로와 VPS·자기·도면 제약 measurement update 경로.

## I-3.1 신경 관성 DR (EqNIO O(2))

### 계보 및 문헌 맥락

신경 관성 오도메트리는 보행자 DR 정확도 향상을 위해 관성 측정 데이터에서 직접 변위를 학습하는 방법론이다. 계보를 간략히 정리하면 다음과 같다.

- **RoNIN** (Robust Neural Inertial Navigation) [Herath 2020]: ResNet·LSTM 기반 스트리밍 신경 DR의 기준 모델. "In the wild" 자연 휴대 방식(주머니, 가방, 손)으로 캡처한 데이터셋(RoNIN)에서 비지도 IMU 프레임을 처리. 보정 없이 방위(yaw)를 외부 AHRS에 의존한다. 즉, per-step 공분산을 출력하지 않는다.

- **TLIO** (Tracking and Learning Inertial Odometry) [Liu 2020]: 두부 장착 VR 헤드셋으로 캡처한 TLIO 데이터셋에서 학습한 LSTM 기반 변위 추정 + per-step 불확실성 공분산 출력. 확률론적 복제(stochastic-cloning EKF)와 결합 시 네트워크만 단독 운용 대비 ~44% ATE 감소(3.079 m → 1.722 m, TLIO 데이터셋 기준).

- **EqNIO O(2)** (Equivariant Neural Inertial Odometry, O(2)-equivariant) [Jayanth 2025]: IMU 프레임 회전에 대해 O(2) 등변(equivariant) 특징 기저를 사용한 신경 오도메트리. 기저 전처리(EqO2Preprocess)가 수평면 회전 군 O(2)의 벡터/스칼라 표현으로 입력을 분해하여 네트워크가 프레임 회전에 대해 예측 결과가 올바르게 변환되도록 보장한다. RoNIN-unseen 분할 ATE를 5.14 m(RoNIN-ResNet 베이스라인) → 4.42 m으로 개선한다고 보고되었으나 [Jayanth 2025], 이 수치는 RoNIN 데이터셋 unseen 분할·프로토콜 기준이며 본 프로젝트와 데이터셋·환경·평가 프로토콜이 다르기 때문에 직접 비교가 불가하다.

**데이터셋 비교불가성 주의**: RoNIN, TLIO, RIDI, OxIOD 데이터셋은 캡처 조건(휴대 방식, 건물 유형, 진실값 시스템)이 상이하여 동일 모델도 데이터셋별로 수 배 이상 ATE 차이를 보인다. 예컨대 GNIO는 OxIOD에서 0.74 m, RoNIN unseen에서 5.02 m을 기록한다 — *동일 모델의 ~7× 스프레드가 데이터셋 차이에서 비롯된다*. 따라서 논문 수치는 각자 데이터셋·분할을 명시해야만 의미가 있으며, 본 시스템 성능과의 직접 비교는 금지한다.

### 입력 파이프라인 (코드 검증)

입력 신호는 다음 단계를 거쳐 모델에 도달한다 (`NeuralOdometry.kt`, `GravityAlignedResampler.kt`, `EqO2Preprocess.kt`에서 확인).

1. **GravityAlignedResampler** — IMU(가속도계·자이로스코프)와 게임회전(game rotation) 행렬을 수신하여 t_grid[i] = origin + i×5,000,000 ns 그리드 상의 균일 시각으로 리샘플링한다. 그리드 간격 DT_NS = 5,000,000 ns이므로 샘플레이트 = **200 Hz**. 각 그리드 샘플에서 IMU를 선형보간하고, 게임회전을 slerp(구면 선형 보간)하여 body-to-world(ENU) 회전 적용 후 `feat[6] = [gx, gy, gz_up, ax, ay, az_up]`(중력정렬 ENU) 피처를 방출한다.

2. **EqO2Preprocess** — 윈도우 200 샘플 × 6 채널을 O(2) 등변 기저로 전처리. 중력 벡터 **g**와 수평 직교 벡터 **v₁**, **v₂**를 구성하여 수평 성분(벡터 채널)과 수직 성분(스칼라 채널)을 분리한다. 출력(평탄 row-major float32):
   - `vector` (1,200,2,3) → 1,200 원소: 수평 벡터 성분 [가속도, v₁, v₂]의 x·y
   - `scalar` (1,200,9) → 1,800 원소: 수직 성분·수평 노름·내적 9개
   - `orig` (1,200,3) → 600 원소: 수직 성분 원본

3. **ModelRunner (eqnio_o2.onnx)** — 위 세 텐서를 입력으로 받아 `vel(1,2) = [vx, vy]`를 출력한다. iOS 구현은 `OrtModelRunner.swift`에서 ONNX Runtime objc를 통해 수행되며, 모델 경로는 `eqnio_o2.onnx` 번들이다. Android는 `OnnxModelRunner.kt`에서 1:1 대응.

4. **NeuralOdometry 방출** — 슬라이딩 윈도우 WINDOW=200, STEP=10(= 0.05 s 스텝). chirality flip 적용: `dy = -vel[1] × 0.05` (ARCore/ARKit x,z 융합 프레임 규약). 방출 시각은 윈도우 끝 다음 그리드 샘플 `ts[s+200]`이다(Python 관행과 동일). 방출 주기는 STEP × 5 ms = **~20 Hz**.

### 출력 및 현재 한계 (코드 검증)

✅ **확인된 사실**: `ModelRunner` 인터페이스 계약(`ModelRunner.kt` 주석)에 명시되어 있으며, `OrtModelRunner.swift`의 출력명 `"vel"`, 크기 2도 이를 확인한다:

> 반환 vel(1,2)=[vx,vy] (모델 좌표계, scale/chirality 미적용).

**현재 EqNIO O(2) 모델(eqnio_o2.onnx)은 변위 `[vx, vy]` 2차원만 출력하며, per-step 공분산(covariance head)이 없다.** TLIO [Liu 2020]의 공분산 출력 헤드 및 X-IONet의 Huber-Gaussian 불확실성 헤드와 달리, 현 구현에서는 covariance 텐서가 모델에 포함되어 있지 않다. 이로 인해:

- PF predict 단계의 프로세스 노이즈는 학습된 공분산이 아니라 손으로 조정한 상수(`motionSigma`, `headingSigma`)를 사용한다 (I-3.2 참조).
- EqNIO 누적 공분산 NEES 측정 및 인플레이션 계수 α 결정이 (측정 예정) 상태다.
- 향후 covariance head 추가 또는 AirIMU-류 누적 공분산 전파기 도입 시 30-compare에서 설명할 DL 개선 여지가 있다.

---

## I-3.2 입자 필터 (2000)

### 상태 공간 및 입자 수

파티클 필터는 `ParticleFilter.kt`에 구현되어 있으며, `PositioningEngine.kt`의 `Config.nParticles = 2000`에서 인스턴스화된다. 각 입자의 상태는 4차원이다:

```
(x, y, θ, K)
```

- `x, y`: 도면 좌표(미터), x 오른쪽·y 아래 맵 프레임
- `θ`: 신경 출력 프레임 → 맵 프레임 회전 (PF 내부 헤딩; 사용자 facing = θ + yawG'(t))
- `K`: per-particle 스케일 팩터 (보폭·신경 프레임 스케일, 기본값 `scaleK = 1.31`)

2,000개 입자는 복도 대칭 모호성과 같은 다중 가설(multimodal posterior)을 표현하기 위한 최소 요건이다.

```mermaid
flowchart LR
    P["Predict (EqNIO + sigma)"] --> W["Weight / update"]
    W --> N{"N_eff < 0.5N?"}
    N -->|Yes| R["Resample"]
    R --> P
    N -->|No| P
```
> 그림: 입자 필터 predict-update-resample 루프 — N_eff 조건부 리샘플링 흐름.

### Predict — Neural Motion Model

Neural predict 경로(`predictNeural`)에서 신경 관성 출력 `(dxN, dyN)`을 입자별 `θ`로 회전하고 입자별 스케일 `K`를 적용하여 맵 프레임 변위를 계산한다:

```
dxMap = K · (cos(θ)·dxN − sin(θ)·dyN)
dyMap = K · (sin(θ)·dxN + cos(θ)·dyN)
```

이후 **손으로 조정한(hand-tuned) 상수** 노이즈를 더한다 (`ParticleFilter.kt` 코드에서 확인):

```kotlin
val nx = prevX + dxMap + gauss() * motionSigma   // motionSigma = 0.02 (m)
val ny = prevY + dyMap + gauss() * motionSigma
val nth = pth[i] + gauss() * headingSigma          // headingSigma = 0.01 (rad)
```

**`PositioningEngine.Config`에서 확인된 실제 파라미터 값**:

| 파라미터 | 값 | 출처 |
|---|---|---|
| `motionSigma` | 0.02 m | `PositioningEngine.kt` Config |
| `headingSigma` | 0.01 rad | `PositioningEngine.kt` Config |
| `nParticles` | 2000 | `PositioningEngine.kt` Config |
| `scaleK` | 1.31 | `PositioningEngine.kt` Config |
| `scaleKSpread` | 0.0 (기본; 선택적) | `ParticleFilter.kt` 생성자 |

**⚠️ 현재 한계**: 위 `motionSigma`·`headingSigma`는 EqNIO 학습 공분산에서 도출된 값이 아니라 경험적으로 조정한 상수다. EqNIO가 per-step covariance head를 갖추면, PF predict의 노이즈 모델을 학습된 공분산으로 대체하거나 스케일 인플레이션(TLIO의 ×10 관행)을 적용해야 한다 [Liu 2020].

### Update — σ-Weighted Likelihood

자기장 measurement update(`update()`)에서 각 입자 위치 `(px[i], py[i])`를 자기장 GP 맵에 질의하여 `(μ, σ)` 쌍을 얻고, 채널별 log-likelihood를 계산한 뒤 가중치를 갱신한다:

```kotlin
val s = sig[k] + measSigmaPerCh[k]   // GP 불확실성 + 측정 노이즈
val d = (z[k] - mu[k]) / s
logl += -0.5 * d * d
w[i] *= exp(logl)
```

채널별 노이즈 `measSigmaPerCh`가 설정된 경우 채널 k에 개별 σ 적용, null이면 단일 `measSigma` 사용(하위 호환). 검증 헤드라인 설정: `measSigmaPerCh = [1e6, 4.0]`(`|B_xy|` 채널 사실상 차단, `B_z`만 σ = 4 μT).

### SIR Resample [Arulampalam 2002]

Systematic resampling(SIR, Sequential Importance Resampling)을 사용하며, 유효 샘플 수 N_eff 조건으로 트리거된다:

```kotlin
fun neff(): Double { var s = 0.0; for (i in 0 until n) s += w[i] * w[i]; return if (s > 0) 1.0/s else 0.0 }
// ...
if (neff() < 0.5 * n) resample()   // N_eff < 0.5 × 2000 = 1000
```

즉, `N_eff < 0.5 N = 1000`이면 systematic resampling을 실행한다 [Arulampalam 2002]. Resample 후 모든 가중치는 `1/N`으로 균일 재설정된다.

### Per-Particle Scale K

스케일 K는 입자별 상태로 추정되어, 잘못된 K의 입자가 지도 우도에 의해 자연히 down-weight·도태되고 K가 온라인으로 수렴한다. `scaleKSigma > 0`일 때 매 predict마다 랜덤워크: `pk[i] += gauss() × scaleKSigma`. 현재 기본 설정은 `scaleKSigma = 0.0`(K 고정).

---

## I-3.3 측정 업데이트

```mermaid
stateDiagram-v2
    [*] --> COLD_START
    COLD_START --> TRACKING : VPS fix accepted
    TRACKING --> RE_ACQUIRE : fix rejected (maxAbsFixRejects)
    RE_ACQUIRE --> TRACKING : new VPS fix accepted
    TRACKING --> GUIDE : conformal gate pass
    TRACKING --> HOLD : conformal gate fail
    GUIDE --> TRACKING
    HOLD --> TRACKING
```
> 그림: 출력 상태기계 — COLD_START·TRACKING·RE_ACQUIRE 전이와 GUIDE/HOLD 출력 판정.

### 자기장 GP 맵 우도 (자기 update) [Solin 2018]

자기장 특징 벡터는 `magUpdate()`에서 생성된다 (`PositioningEngine.kt`에서 확인):

```kotlin
private fun magUpdate(p: ParticleFilter) {
    if (lastMagAcc < config.minMagAccuracy) return   // 정확도 미달 시 skip
    val r = lastR9 ?: return
    val m = lastMagDev ?: return
    val w = worldB(r, m[0], m[1], m[2])
    p.update(floatArrayOf(
        hypot(w[0].toDouble(), w[1].toDouble()).toFloat(),   // |B_xy|
        w[2]                                                   // B_z
    ))
}
```

게임회전 행렬 R(world←device)을 사용해 device-frame 자기 triad를 world-frame으로 변환한 뒤, 수평 강도 `|B_xy| = √(Bx²+By²)`와 수직 성분 `B_z` 2채널을 특징으로 사용한다. `worldB()` 변환은 자북 무관(yaw-invariant)으로 설계되어 있어, 절대 방위를 모르는 상태에서도 적용 가능하다.

자기장 GP 지도 `GpMagneticMap`은 격자 `(μ, σ)` 쌍으로 구성되며 이중선형보간(bilinear interpolation)으로 질의된다. 격자 밖은 σ = 1e6으로 처리하여 likelihood를 평탄화한다. 자기 우도는 GP(Gaussian Process) 과정 특성 추정을 위한 사전 학습 기반이다 [Solin 2018].

**자기 정확도 게이트**: `lastMagAcc < minMagAccuracy (= 2)` 이면 해당 스텝의 자기 update를 스킵한다. Android는 `SensorManager` 정확도 0~3, iOS는 `CMCalibratedMagneticField` 정확도를 사용한다.

**현재 한계 (cross-core 실측)**: 융합 cross-core 결과에 따르면 자기 보정의 위치 개선 기여도는 현재 ~0으로 측정되었다. 이는 실내 자기 왜곡(금속 구조물·전기 설비)으로 인한 지도-측정 불일치 때문으로 추정된다. 자기 채널은 퇴화 방지 및 장기적 개선 여지를 위해 파이프라인에 유지된다.

### VPS 절대 재앵커 (위치 + 헤딩 리셋)

VPS 픽스 도착 시 `onVpsFix(fix: VpsFix)` 경로에서 두 단계 업데이트가 수행된다 (`PositioningEngine.kt`에서 확인):

**1단계 — Spatial Gate (위치 기각)**:

`updatePositionSafe()`에서 정규화 잔차를 계산한다:

```kotlin
val std = positionStd()   // 입자 분포 표준편차
val denom = sqrt(std² + sigma²)
val d = hypot(ex - zx, ey - zy) / denom
if (d > gateSigma) return false   // 기각
```

`gateSigma = absFixGateSigma = 5.0` (Config에서 확인). 즉, 정규화 거리 `‖est − z‖ / √(std² + σ²) > 5`이면 픽스를 기각한다. 연속 기각 횟수가 `maxAbsFixRejects = 3`에 도달하면 필터 락 탈출로 무조건 적용한다.

**2단계 — 위치 우도 + 헤딩 리셋**:

기각되지 않은 픽스에 대해 `updatePosition()`으로 위치 우도 update 후, `resetHeading()`으로 절대 헤딩 리셋을 수행한다:

```kotlin
val applied = applyGatedFix(p, fix.x, fix.y, fix.sigmaM)
if (applied) p.resetHeading(fix.thetaRad - lastYawG, config.vpsHeadingResetSpreadRad)
```

`vpsHeadingResetSpreadRad = 5° = 5 × π/180 rad` (Config에서 확인). 모든 입자의 θ를 `fix.thetaRad − lastYawG ± 5°` 균일 분포로 재배치하여 DR yaw 드리프트를 일시에 제거한다.

**VpsFix 구조** (`VpsLocator.kt`에서 확인):
- `thetaRad`: OpenCV +Z 전방·atan2(fz, fx) 규약 — 엔진 DR 정합 (VPS heading 규약 참조)
- `sigmaM`: 위치 불확실도(미터, PnP 신뢰도)
- `tNs`: 픽스 타임스탬프 (셔터시각, 지연 보정에 사용)

### Walkable Manifold 제약 (CoverageMask · WallMap)

`predictNeural()`에서 두 가지 공간 제약이 적용된다:

- **CoverageMask**: `coverageMask.contains(nx, ny)`가 false이면 `w[i] = 0.0` (커버리지 밖 = 무효 입자)
- **WallMap**: zone별 hard/soft/off 모드. `HARD` 모드 구역에서 이동 선분이 벽을 교차하면 `w[i] = 0.0`. `SOFT` 모드에서는 `w[i] *= softWallFactor(= 0.1)`.

입자 고갈(depletion) 시 `absorbDepletion()`이 호출된다. `N_eff < 0.5N`이면 생존자 입자로 resample하여 전멸을 방지한다.

---

## I-3.4 타이밍 / OOSM

```mermaid
sequenceDiagram
    participant Camera
    participant Engine
    participant VPS
    Camera->>Engine: shutter t_photo (snapshot to ring buffer)
    Note over Engine: ~20s elapses (IMU data accumulates)
    VPS->>Engine: fix arrives (late)
    Engine->>Engine: retrodict to t_photo, apply heading reset
```
> 그림: 지연 VPS fix의 셔터시각 앵커(OOSM) — 셔터 시각 기준으로 헤딩을 역추정하는 시퀀스.

### 셔터시각 헤딩 Retrodiction

VPS 파이프라인(hloc 검색 + 특징 매칭 + PnP)은 서버 왕복 및 연산 지연으로 인해 현재 **~20 s**의 도착 지연이 발생한다. 이 fix는 도착 시각이 아닌 **셔터시각(t_photo)**에서의 상태를 기술한다.

헤딩 retrodiction은 `yawGAt()` 함수와 `yawHist` 링버퍼로 구현되어 있다 (`PositioningEngine.kt`에서 확인):

```kotlin
// 링버퍼: (tNs, yawG) 쌍을 30 s 보관
private val yawHist = ArrayDeque<YawSample>()
private val yawHistMaxAgeNs = 30_000_000_000L    // 30 s

// onGameRotation에서 매 게임회전마다 적재·만료 정리
yawHist.addLast(YawSample(tNs, lastYawG))
while (yawHist.size > 1 && tNs - yawHist.first().tNs > yawHistMaxAgeNs) yawHist.removeFirst()

// 셔터시각에 가장 가까운 yawG 검색 (선형 탐색)
private fun yawGAt(tNs: Long): Double {
    ...
    var best = yawHist.first(); var bestD = abs(best.tNs - tNs)
    for (s in yawHist) { val d = abs(s.tNs - tNs); if (d < bestD) { bestD = d; best = s } }
    return best.yawG
}
```

`yawHist`는 30 s 링버퍼로, 200 Hz 게임회전 샘플을 저장하고 만료된 샘플을 자동으로 삭제한다. VPS 픽스 도착 시 `fix.tNs`(셔터시각)를 키로 가장 가까운 `yawG`를 역추정하여 헤딩 리셋에 사용한다 [Bar-Shalom 2002] [Bar-Shalom 2004]:

```kotlin
val seedTheta = fix.thetaRad - yawGAt(fix.tNs)   // 셔터시각 yawG로 θ 보정
```

이 방식은 Bar-Shalom의 OOSM retrodiction 원칙 — "지연 측정을 도착 시각이 아닌 측정 시각에 앵커해야 오차 타원이 최소화된다" — 을 헤딩 차원에 한정 적용한 것이다 [Bar-Shalom 2002].

### 현재 OOSM 처리 한계

**⚠️ 명시적 한계**: 현재 구현은 **헤딩 역추정만 셔터시각에 적용하며, 위치 업데이트는 fix 도착 시각에 적용**된다. 이는 부분적 OOSM 보정이다.

```kotlin
// onVpsFix()에서: 위치 update는 fix 도착 현재 입자 분포에 적용됨
val applied = applyGatedFix(p, fix.x, fix.y, fix.sigmaM)   // 도착시각 분포
if (applied) p.resetHeading(fix.thetaRad - lastYawG, ...)  // 헤딩만 셔터시각 yaw 사용
```

위치 OOSM 완전 처리(per-particle 스냅샷 링버퍼 + 지연 weight update 또는 GARP reseed)는 미구현 상태다. Bar-Shalom [Bar-Shalom 2002]의 B-l1 알고리즘은 단일 스텝 비용으로 최적에 1% MSE 이내를 달성할 수 있음을 보였으나, 이를 위해서는 per-particle 상태 스냅샷(2,000 입자 × 최대 ~1,000 스텝 × 4바이트 × 3(x, y, θ) ≈ 수십 MB)의 추가 저장 구조가 필요하다.

**위치 OOSM 미처리의 영향**: 약 20 s 지연 후 도착한 VPS 픽스를 도착 시각 입자 분포에 적용하면, 그 사이 보행 거리(~1.2 m/s × 20 s = ~24 m)에 해당하는 입자 분산 대비 VPS σ (수십 cm)가 크게 작아 N_eff가 급격히 감소할 수 있다. 현재 구현에서는 `absFixGateSigma = 5.0`의 공간 게이트와 `maxAbsFixRejects = 3`의 락탈출로 완전 N_eff 붕괴를 방어하고 있으나, 완전한 해결책은 아니다.

완전한 위치 OOSM 처리를 위한 경로는 두 가지다:
- **Path A (iSAM2 / right-invariant fixed-lag smoother)**: 지연 fix를 factor graph에 타임스탬프 노드로 삽입하면 OOSM이 자동 흡수된다 [Bar-Shalom 2004]. 단, naive marginalizing FLS는 NEES가 657까지 상승해 오히려 fix를 기각하므로 right-invariant FLS 또는 iSAM2 필수.
- **Path B (per-particle 스냅샷 + GARP reseed)**: 셔터 시각에 입자 스냅샷 캐시 후, fix 도착 시 N_eff_post / N_eff_prior < 1/40 조건에서 GARP(Gaussian Approximation Re-run with Particles) sub-sample reseed 수행.

---

## 인용

상세 참고문헌 표기는 [90-appendix.md](./90-appendix.md)를 따른다.

| 키 | 정보 |
|---|---|
| [Jayanth 2025] | Jayanth et al., "EqNIO: Equivariant Neural Inertial Odometry" (preprint under review) |
| [Herath 2020] | Herath et al., "RoNIN: Robust Neural Inertial Navigation in the Wild," ICRA 2020 |
| [Liu 2020] | Liu et al., "TLIO: Tight Learned Inertial Odometry," RA-L 2020 |
| [Arulampalam 2002] | Arulampalam et al., "A Tutorial on Particle Filters for Online Nonlinear/Non-Gaussian Bayesian Tracking," IEEE TSP 2002 |
| [Solin 2018] | Solin et al., "Terrain Navigation in the Magnetic Landscape: Particle Filtering for Indoor Positioning," EUSIPCO 2018 |
| [Bar-Shalom 2002] | Bar-Shalom, "Update with Out-of-Sequence Measurements in Tracking: Exact Solution," IEEE TAC 2002 |
| [Bar-Shalom 2004] | Bar-Shalom et al., "One-Step Solution for the Multistep Out-of-Sequence-Measurement Problem in Tracking," IEEE TAE 2004 |
