# 10. 통합 캡처·서베이 & VPS 맵빌드·측위

> **버전** v0.1-draft · **날짜** 2026-06-25 · **상태** ✅완료(I-1 캡처, I-2 VPS 맵빌드·측위)
> 이 파일은 Part I 공통 코어 중 캡처 및 VPS 절반을 다룬다. 이후 파일 11(라이브 융합)·12(드리프트 보정·검증)·21(iOS 프로파일 — 콜드스타트·지연 참조)이 이 파일의 실증 수치와 파이프라인 정의를 인용한다.

---

## I-1 통합 캡처 & 서베이

### I-1.1 통합 캡처 개요

실내 측위 파이프라인은 단일 도보 세션에서 다음 네 가지 데이터를 **동일한 ARKit 월드 좌표계** 아래 동시 수집한다.

| 채널 | 내용 | 도구 |
|------|------|------|
| RGB 영상 | 60fps H.264 (`rgb.mp4`) — VPS 맵빌드·측위의 원본 | ARKit AVCaptureSession |
| ARKit odometry | 프레임별 6-DoF pose + 카메라 intrinsics (`odometry.csv`) | ARKit 트래킹 |
| RoomPlan 3D 도면 | 벽·문·창·가구 기하 (`room.usdz`) — 이동가능영역 제약 원본 | RoomPlan API |
| FP(지문) 데이터 | IMU 로그, BLE(추후), 자기장 — 서베이 기반 위치 지문 | CoreMotion |

이 설계는 StrayScanner [Ott 2021] 형식의 superset이다. StrayScanner는 RGB + depth + 카메라 pose를 동시 기록하는 공개 iOS 앱으로, 본 캡처 파이프라인은 그 포맷 규약(ARKit world Y-up, OpenCV 카메라 규약 적용)을 계승하면서 RoomPlan 도면과 측위 FP 레이어를 추가한다. 단일 세션에서 수집하므로 도면·VPS·자기 지도·odometry가 모두 동일 좌표계를 공유하며, 사후 정합(registration) 작업이 불필요하다.

〔이미지: 통합 캡처 화면 — RoomPlan 실시간 3D + 도보 세션 진행 표시〕

![RoomPlan floorplan — top-down view of room.usdz (walls, doors, windows, furniture) with ARKit camera trajectory overlay, iPhone 15 Pro, iOS 27](../../vps/results/roomplan_floorplan.png)
> 그림: RoomPlan API로 생성된 도면 — 벽(13개)·문·창문·가구 기하와 ARKit 카메라 궤적(파란 선) 탑다운 뷰. iPhone 15,3·iOS 27·ARKit world x–z 좌표계. 서베이 세션 `20260623-113521` 실측 결과물.

### I-1.2 GT 앵커 — N점 상사변환

VPS 맵과 평면도의 절대 위치를 체크포인트 GT에 연결하려면 **N점 유사변환(similarity transformation)** 을 추정해야 한다. 구체적으로는 스케일 s, 회전 R, 이동 t를 동시에 풀어 소스 좌표계를 타깃 GT에 정렬하는 폐형(closed-form) 해를 사용한다 [Umeyama 1991]. Umeyama 1991은 N 대응점 집합에서 최소제곱 상사변환을 SVD로 직접 풀어내며, 스케일 자유도를 포함해 ARKit metric 좌표와 평면도 픽셀 좌표 사이의 닮음변환을 안정적으로 추정한다. 구현에서는 `GeoReference` 모듈이 2점 특수화를 사용하여 도면 픽셀 좌표와 ARKit meter 좌표 간 변환을 실시간 계산한다(커밋 `bdab3ee`).

> 주의: 현 단계 GT 앵커는 ARKit odometry를 기준으로 하며, 이는 **드리프트를 포함한 상대 측정**이다. 측위 절대정확도 벤치마크를 위해서는 ATE(Absolute Trajectory Error) 측정용 토탈스테이션 또는 다점 레이저 기준점이 필요하다(⏳ 예정).

### I-1.3 걷기 서베이 — 탭-보행-탭

FP 서베이는 **탭-보행-탭(tap-walk-tap)** 방식으로 수행한다. 사용자가 알려진 위치에서 시작 탭을 누르고, 이동 경로를 걸으며, 다음 알려진 위치에서 종료 탭을 누르는 IndoorAtlas 방식과 동일하다 [Solin 2018]. 한 세션에서 걷기 경로가 공간을 충분히 커버하도록 다음 프로토콜을 따른다 (`vps/survey_protocol.md`):

- 천천히 부드럽게 이동(모션블러 방지)
- 카메라를 벽면에 겨눠 좌우로 훑기(대상 면 특징 밀도 증가)
- 양방향·다경로로 공간 커버 + 루프 클로저(복귀 방문)
- 포스터·모서리·물체 등 텍스처 면 우선, 단색 흰 벽·유리 지양

발열 제약: 60fps RoomPlan+RGB+센서 동시 수집으로 ~4분이면 iOS thermal SERIOUS 가능 → 넓은 공간은 구간별로 나눠 캡처한다.

---

## I-2 VPS 맵빌드 & 측위

```mermaid
flowchart TD
    A["Survey images"] --> B["COLMAP SfM"]
    B --> C["3D map + NetVLAD index"]
    D["Query image"] --> E["NetVLAD retrieval"]
    E --> F["SuperPoint + LightGlue match"]
    F --> G["PnP + RANSAC"]
    G --> H["6-DoF pose (VpsFix)"]
```
> 그림: VPS 맵빌드·측위 파이프라인 — 서베이 이미지로 맵을 구축하고 쿼리 이미지로 6-DoF pose를 추정하는 전체 흐름.

### I-2.1 파이프라인 개요

VPS(Visual Positioning System) 파이프라인은 서베이 세션 이미지로 오프라인에 **시각 지도(VPS 맵)** 를 구축하고, 런타임에 쿼리 이미지 한 장으로 6-DoF pose를 추정한다. 전체 흐름은 다음과 같다.

```
서베이 세션
  rgb.mp4 → 프레임 추출(매 15번째)
  odometry.csv → ARKit pose + intrinsics
        ↓
arkit_to_colmap.py          ARKit world→COLMAP world→camera 변환
  (Y-up, −Z 전방 → +Z 전방, Y-down; R_cw = R_wc^T, t_cw = −R_cw·C)
        ↓
hloc build_map.py           계층적 측위 [Sarlin 2019]
  1. SuperPoint 특징 추출   [DeTone 2018]
  2. pose 기반 페어 선택    (ARKit pose 근접 → co-visible 추정)
  3. LightGlue 매칭         [Lindenberger 2023]
  4. 삼각측량(알려진 pose)  → metric 3D 점군 (VPS 맵)
        ↓
VPS 맵 (COLMAP SfM 형식)
  = 3D 점군 + 이미지별 SuperPoint 특징 + ARKit metric 스케일

런타임 측위 (vps/vps_service.py — POST /localize)
  쿼리 JPG
  → SuperPoint 추출(상주 MPS 모델)
  → NetVLAD 전역 검색(상주 db 텐서)   top-20 retrieval
  → LightGlue 매칭(상주 CPU 모델)
  → PnP+RANSAC (pycolmap, RANSAC max_error=12px, seed=0)
  → VpsFix {x, y, thetaRad, sigmaM, inliers}
```

hloc [Sarlin 2019]는 전역 검색(NetVLAD retrieval)과 지역 매칭(SuperPoint+LightGlue)을 계층적으로 결합하는 프레임워크로, 쿼리와 가장 유사한 데이터베이스 이미지를 먼저 고른 뒤 해당 이미지와만 매칭을 수행해 계산 비용을 줄인다. COLMAP [Schönberger 2016]은 SfM 재구성 및 PnP solver 기반의 측위를 제공한다.

**좌표 변환 규약**: ARKit는 camera→world 변환(Y-up, 카메라 −Z 전방)을 사용하고, COLMAP은 world→camera 변환(+Z 전방, Y-down)을 요구한다. `arkit_to_colmap.py`에서 R_cw = R_wc^T, t_cw = −R_cw · C 로 변환한다. 월드 좌표계는 ARKit(중력정렬 Y-up)을 그대로 유지하므로 자기장 지도·RoomPlan 도면과 동일 좌표계를 공짜로 공유한다.

**heading 규약**: VpsFix.thetaRad = atan2(fz, fx), 여기서 fwd = R_cw^T · [0, 0, 1] (OpenCV +Z 전방). 이 규약이 DR 엔진의 heading 정의와 일치해야 보행 시 궤적이 반사 왜곡 없이 정합된다 (Memory: vps-heading-convention).

〔이미지: SuperPoint 키포인트 + LightGlue 매칭 예시 — 쿼리 이미지와 데이터베이스 이미지 간 대응점〕

### I-2.2 특징 추출기 실제 구현

> **코드 검증 노트:** 실제 스택은 hloc + SuperPoint(`superpoint_aachen`) + NetVLAD(전역 검색) + LightGlue임을 코드에서 확인하였다. `vps/build_map.py` line 46의 `extract_features.confs["superpoint_aachen"]`, `vps/localize.py` line 53의 동일 설정, `vps/vps_service.py` lines 59–62의 `FCONF/MCONF` 설정이 모두 SuperPoint + LightGlue 조합임을 검증하였다.

사용 구성 요소:

| 역할 | 구현 | 논문 |
|------|------|------|
| 지역 특징 추출 | SuperPoint (`superpoint_aachen` config, n=4096, r=1024px) | [DeTone 2018] |
| 전역 검색(retrieval) | NetVLAD | [Arandjelović 2016] |
| 특징 매칭 | LightGlue (`superpoint+lightglue` config) | [Lindenberger 2023] |
| SfM 재구성 및 PnP | pycolmap (COLMAP Python binding) | [Schönberger 2016] |
| 계층적 측위 프레임워크 | hloc | [Sarlin 2019] |

벤치마크 맥락: LaMAR [Sarlin 2022] 벤치마크는 병원·쇼핑몰 등 실내 대규모 환경에서 hloc 계열 파이프라인의 측위 성능을 체계적으로 평가한다. 본 시스템의 단일 건물 코리도 환경 결과(아래)와 LaMAR 수치는 데이터셋·프로토콜·환경 규모가 상이하여 직접 수치 비교가 불가하다.

### I-2.3 모델 영속화 — 응답 단축 (~18 s → <5 s)

초기 구현(`7790e17`)은 요청마다 SuperPoint·NetVLAD·LightGlue·SfM을 재로딩했기 때문에 응답 시간 중앙값이 ~18 s에 달했다. `a7d9c0f` (feat(vps): 모델 영속화)에서 이 세 모델과 SfM 재구성·db 전역 디스크립터 텐서를 서버 기동 시 1회 로드 후 상주시키고, 요청당 쿼리 추론만 수행하도록 변경하였다.

추가 최적화:
- **하이브리드 디바이스**: 특징 추출(SuperPoint/NetVLAD)은 MPS(고정 shape 1024px → 재컴파일 없음), LightGlue 매칭은 CPU(가변 키포인트 shape라 MPS는 요청마다 재컴파일 → 느림)
- **결정론**: RANSAC `random_seed=0, num_threads=1` 고정 → 영속본과 현재본의 inlier 수 오차 ≤8 보장

**parity 게이트** (`vps/test_parity.py`): 5개 golden 이미지(`vps/parity_golden.json`)에 대해 좌표 허용오차(x/y ≤0.05 m, theta ≤0.02 rad, inlier ±8)와 지연 게이트(<5,000 ms)를 자동 검사한다. CI/배포 전 통과 여부를 확인해야 한다.

### I-2.4 실증 결과

> **테스트 비교불가성 주의:** 아래 세 테스트는 데이터셋·환경·프로토콜이 서로 다르다. 수치를 교차 비교할 수 없으며, 각 테스트의 라벨 및 조건을 별도로 읽어야 한다.

#### ① 맵빌드 reproj 자기검증 (build self-check, sloppy walk)

- **테스트**: 복도 sloppy walk 세션, 63장 매핑, 63/63 등록, 1,446개 3D점
- **결과**: 평균 reprojection 오차 **1.685 px** (커밋 `c1336ff`)
- **의미**: reprojection 오차가 낮을수록 ARKit→COLMAP 좌표변환과 SuperPoint+LightGlue 매칭이 정상임을 결정론적으로 확인. 이 수치 자체는 맵이 자신의 입력 이미지에 얼마나 잘 맞는지를 나타내며, 홀드아웃 측위 정확도와는 다른 지표이다.

#### ② hold-out 측위 정확도 (proper survey, iOS iPhone 15 Pro)

- **테스트**: proper survey 세션 `20260623-113521` (iPhone 15 Pro, iOS 27 Beta, 126 s, 60 fps)
  - 맵: 500개 이미지, 38,610개 3D점, reproj 중앙값 **1.67 px**
  - 홀드아웃: 50개 쿼리 (맵에 없는 같은 공간 별도 경로 프레임)
  - NetVLAD retrieval → LightGlue 매칭 → PnP+RANSAC
- **결과**: 위치오차 중앙값 **7.6 cm**, <0.25 m **98%**, 최대 오차 ~0.3 m (커밋 `f841e6d`, `a430ebf` 파일명 충돌 픽스 후)
- **비교불가성**: 이 수치는 proper survey 데이터, 50 쿼리 홀드아웃이라는 특정 프로토콜 결과이다. sloppy walk 데이터, 다른 환경, 다른 기기에서는 다른 값이 나올 수 있다.

#### ③ 1차 localize 검증 (sloppy walk, iOS)

- **테스트**: sloppy walk 세션, 63장 맵 / 63장 홀드아웃 쿼리 (맵 내 같은 경로 프레임)
- **결과**: 등록 **100%** (63/63), 위치오차 중앙값 **0.37 m**, <0.5 m **89%**, <1 m **90%** (커밋 `4425a6f`)
- **비교불가성**: 맵과 쿼리가 같은 walk에서 나온 것으로, 적절히 분리된 홀드아웃보다 낙관적일 수 있다. proper survey 세션(②)보다 오차가 큰 이유는 sloppy walk의 낮은 맵 품질(적은 멀티뷰 오버랩, 모션블러)이 원인이다.

#### ④ 크로스디바이스 등록률 / inlier (indoorpos-android)

- **테스트**: iOS iPhone으로 구축한 VPS 맵에 Android 기기 쿼리 이미지로 측위(STEP3 교차 플랫폼 검증)
- **결과**: 등록률 **~80%**, 중앙값 inlier 수 **26** (2026-06-26 진행 보고서, `docs/회의_2026-06-26_진행보고.md`)
- **비교불가성**: 위 iOS 홀드아웃 테스트(②③)와 쿼리 기기, 해상도, 카메라 특성이 다르다. inlier 26은 proper survey iOS(②) 대비 낮으나 — 이는 기기 간 카메라 특성 차이(렌즈 왜곡, 화이트밸런스, 해상도)가 SuperPoint 키포인트 분포와 매칭 성공률에 영향을 주기 때문이다. 크로스디바이스 등록률과 inlier 수치는 원시 테스트 커밋 단독이 아닌 진행보고서에서 확인된 것으로, 정밀 hold-out 벤치마크 수준의 검증이 아님을 명시한다. (정밀 크로스디바이스 벤치마크 ⏳ 예정)

![VPS validation: (A) VPS map point cloud + ARKit camera trajectory top-down; (B) GT vs VPS estimate scatter (after fix vs before fix); (C) localization error CDF for 50 hold-out queries — median 7.6 cm after fix](../../vps/results/vps_validation.png)
> 그림: VPS 검증 결과 (서베이 `20260623-113521`, iPhone 15 Pro, iOS 27, 60fps). **A** — VPS 맵 점군(38,610점)과 ARKit 카메라 궤적 탑다운 뷰. **B** — hold-out 쿼리 50개의 GT 위치 vs VPS 추정 위치 산점도(픽스 이전·이후 비교). **C** — 위치오차 CDF: fix 이후 중앙값 7.6 cm, 상위 98%가 0.25 m 미만. 실측 데이터 아티팩트.

![VPS hold-out position error CDF (illustrative, anchored to measured stats: median 7.6 cm, P98 < 0.25 m)](./figures/vps_holdout_cdf.png)
> 그림: VPS hold-out 위치오차 CDF — 반정규(half-normal) 분포로 **실측 통계값(중앙값 7.6 cm, P98 < 0.25 m)에 앵커된 예시 곡선(ILLUSTRATIVE)**. 원시 쿼리별 측정 데이터가 아님. n=50 홀드아웃 쿼리 기준, 서베이 `20260623-113521`, iOS.

### I-2.5 응답 지연 & OOSM 처리 (전방참조)

VPS 파이프라인 — 이미지 전송(LAN HTTP) + SuperPoint 추출 + NetVLAD 검색 + LightGlue 매칭 + PnP — 은 네트워크 왕복 및 연산으로 인해 다중 초의 지연이 발생한다. 모델 영속화 이후 서버측 중앙값은 <5 s 이나, iOS → 서버 왕복 포함 실사용 지연은 환경에 따라 더 클 수 있다.

이 지연을 단순히 도착 시각에 fix를 주입하면 파티클 분포와 VPS 정밀도 사이의 σ 불일치로 N_eff가 붕괴한다. 올바른 처리 방법은 **셔터 시각(t_photo)을 키로 하는 링 버퍼에 상태 스냅샷을 저장하고, fix 도착 시 해당 시점에 앵커하는 것(OOSM)** 이다. 이에 대한 상세는 `11-core-fusion.md` §I-3.4 (OOSM) 및 `21-platform-ios.md` §II-B.3 (콜드스타트 견고화)를 참조한다.

---

*다음 파일: [11-core-fusion.md](./11-core-fusion.md) — 라이브 융합 엔진(EqNIO+PF+측정 업데이트+OOSM)*
