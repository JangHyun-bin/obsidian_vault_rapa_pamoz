"""
make_figures.py — Generate illustrative methodology figures for docs/methodology/.

ALL in-figure text is in ENGLISH (Korean fonts not available in headless env).
Run: python docs/methodology/figures/make_figures.py
Output: docs/methodology/figures/{drift_budget,heading_drift,vps_holdout_cdf}.png
"""

import matplotlib
matplotlib.use("Agg")  # non-interactive backend — no display required

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from scipy import stats
import os

OUT_DIR = os.path.dirname(os.path.abspath(__file__))

# ─────────────────────────────────────────────────────────────
# P1: drift_budget.png
# Re-anchor interval vs expected tail position error (m)
# ─────────────────────────────────────────────────────────────

def make_drift_budget():
    fig, ax = plt.subplots(figsize=(8, 5))

    t = np.linspace(0, 300, 600)  # seconds

    # Drift rates in m/min → convert to m/s
    rates = {
        "0.4 m/min (low)":  0.4 / 60,
        "1.0 m/min (mid)":  1.0 / 60,
        "1.5 m/min (high)": 1.5 / 60,
    }
    colors = ["#2196F3", "#FF9800", "#F44336"]

    for (label, rate), color in zip(rates.items(), colors):
        y = rate * t
        ax.plot(t, y, label=label, color=color, linewidth=2)

    # Horizontal dashed baseline at 2.7 m (documented neural-IO drift result)
    ax.axhline(2.7, color="gray", linestyle="--", linewidth=1.5,
               label="Baseline neural-IO ATE 2.7 m")

    # Shade design ceiling 90–120 s
    ax.axvspan(90, 120, alpha=0.15, color="#4CAF50", label="Design ceiling (90–120 s)")

    ax.set_xlabel("VPS re-anchor interval (s)", fontsize=12)
    ax.set_ylabel("Expected tail position error (m)", fontsize=12)
    ax.set_title(
        "Re-anchor interval vs tail position error\n"
        "(illustrative; from documented DR drift rates)",
        fontsize=11,
    )
    ax.set_xlim(0, 300)
    ax.set_ylim(0, 8)
    ax.legend(fontsize=10, loc="upper left")
    ax.grid(True, alpha=0.3)

    fig.tight_layout()
    out = os.path.join(OUT_DIR, "drift_budget.png")
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"Saved: {out}")


# ─────────────────────────────────────────────────────────────
# P2: heading_drift.png
# Heading error (deg) and lateral error (m) vs time, 4.5 deg/min
# ─────────────────────────────────────────────────────────────

def make_heading_drift():
    fig, ax1 = plt.subplots(figsize=(8, 5))

    t = np.linspace(0, 180, 360)  # seconds, 0–180 s

    drift_rate_deg_per_sec = 4.5 / 60  # 4.5 deg/min
    heading_err = drift_rate_deg_per_sec * t  # deg

    # Lateral error: integrate along a straight walk at 1 m/s
    # lateral ≈ distance × sin(heading_err_rad) ≈ distance × heading_rad (small angle)
    distance = 1.0 * t  # m (1 m/s)
    heading_err_rad = np.deg2rad(heading_err)
    lateral_err = distance * np.sin(heading_err_rad)

    # Left axis: heading error (deg)
    color1 = "#1565C0"
    ax1.plot(t, heading_err, color=color1, linewidth=2, label="Heading error (deg)")
    ax1.set_xlabel("Time (s)", fontsize=12)
    ax1.set_ylabel("Heading error (deg)", fontsize=12, color=color1)
    ax1.tick_params(axis="y", labelcolor=color1)

    # Right axis: lateral error (m)
    ax2 = ax1.twinx()
    color2 = "#C62828"
    ax2.plot(t, lateral_err, color=color2, linewidth=2, linestyle="--",
             label="Lateral error (m, @ 1 m/s walk)")
    ax2.set_ylabel("Lateral position error (m)", fontsize=12, color=color2)
    ax2.tick_params(axis="y", labelcolor=color2)

    # Vertical lines at 90 s and 120 s (re-anchor window)
    ax1.axvline(90,  color="#388E3C", linestyle=":", linewidth=1.8, label="t = 90 s (re-anchor window start)")
    ax1.axvline(120, color="#1B5E20", linestyle=":", linewidth=1.8, label="t = 120 s (re-anchor window end)")

    ax1.set_xlim(0, 180)
    ax1.set_ylim(0)
    ax2.set_ylim(0)
    ax1.set_title(
        "Uncorrected heading drift at 4.5 deg/min (illustrative)",
        fontsize=11,
    )
    ax1.grid(True, alpha=0.3)

    # Combined legend
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc="upper left")

    fig.tight_layout()
    out = os.path.join(OUT_DIR, "heading_drift.png")
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"Saved: {out}")


# ─────────────────────────────────────────────────────────────
# P3: vps_holdout_cdf.png
# VPS hold-out error CDF (ILLUSTRATIVE, anchored to measured stats)
# median ≈ 0.076 m, ~98% < 0.25 m
# ─────────────────────────────────────────────────────────────

def make_vps_holdout_cdf():
    fig, ax = plt.subplots(figsize=(8, 5))

    rng = np.random.default_rng(42)

    # Fit a half-normal whose median ≈ 0.076 m
    # Half-normal CDF: F(x) = erf(x / (sigma * sqrt(2)))
    # Median of half-normal: sigma * sqrt(2) * erfinv(0.5)
    # erfinv(0.5) ≈ 0.4769
    # => sigma = 0.076 / (sqrt(2) * 0.4769) ≈ 0.1129
    # Check P98: P(X < 0.25) = erf(0.25 / (sigma * sqrt(2)))
    # = erf(0.25 / 0.1597) = erf(1.565) ≈ 0.980  ✓
    sigma = 0.076 / (np.sqrt(2) * 0.4769)

    n_samples = 50  # match the actual 50 hold-out queries
    errors = np.abs(rng.normal(0, sigma, n_samples))

    # Empirical CDF
    sorted_errors = np.sort(errors)
    cdf = np.arange(1, n_samples + 1) / n_samples

    ax.step(sorted_errors, cdf, where="post", color="#1565C0", linewidth=2,
            label="Hold-out error CDF (illustrative, n=50)")

    # Mark median 7.6 cm
    median_val = 0.076
    ax.axvline(median_val, color="#F57C00", linestyle="--", linewidth=1.8)
    ax.annotate(
        "Median 7.6 cm",
        xy=(median_val, 0.5),
        xytext=(median_val + 0.03, 0.42),
        fontsize=10,
        color="#E65100",
        arrowprops=dict(arrowstyle="->", color="#E65100", lw=1.5),
    )

    # Mark P98 at 0.25 m
    ax.axvline(0.25, color="#B71C1C", linestyle="--", linewidth=1.8)
    ax.axhline(0.98, color="#B71C1C", linestyle=":", linewidth=1.2, alpha=0.6)
    ax.annotate(
        "P98 < 0.25 m",
        xy=(0.25, 0.98),
        xytext=(0.17, 0.88),
        fontsize=10,
        color="#B71C1C",
        arrowprops=dict(arrowstyle="->", color="#B71C1C", lw=1.5),
    )

    ax.set_xlabel("Position error (m)", fontsize=12)
    ax.set_ylabel("Cumulative fraction", fontsize=12)
    ax.set_xlim(0, 0.35)
    ax.set_ylim(0, 1.05)
    ax.set_title(
        "VPS hold-out position error CDF\n"
        "(ILLUSTRATIVE; anchored to measured median 7.6 cm, P98 < 0.25 m,\n"
        "proper survey 20260623-113521, iOS)",
        fontsize=10,
    )
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)

    fig.tight_layout()
    out = os.path.join(OUT_DIR, "vps_holdout_cdf.png")
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"Saved: {out}")


if __name__ == "__main__":
    make_drift_budget()
    make_heading_drift()
    make_vps_holdout_cdf()
    print("All figures generated.")
