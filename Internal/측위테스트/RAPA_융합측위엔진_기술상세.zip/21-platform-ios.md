# II-B. 플랫폼 프로파일 — iOS

> **버전** v0.1-draft · **날짜** 2026-06-25 · **상태** 초안
> 이 파일(Part II-B)은 iOS 플랫폼에 특화된 센서 스택, 자기 3겹 보정, 콜드스타트 견고화, **iOS-고유 A-B-A 드리프트 근본원인**을 기록한다. 플랫폼 간 비교는 [30-compare-converge.md](./30-compare-converge.md) 참조.
> 코어 공통 알고리즘(EqNIO, 입자 필터, 라이브 융합 엔진)은 [11-core-fusion.md](./11-core-fusion.md) (Part I-3)에 있으며, 본 파일은 iOS-고유 레이어만 기술한다.
>
> 코드 검증 출처:
> - `iosApp/Sources/Engine.swift`
> - `docs/ios-drift-rootcause.md`

---

## II-B.1 센서 스택

코어 공통부는 I-3 참조.

### 회전 소스 — CoreMotion `.xMagneticNorthZVertical` (자력계 융합)

iOS 센서 브리지(`iosApp/Sources/Engine.swift:134`)는 `CMMotionManager.deviceMotion`을 200 Hz로 구동하고, attitude 참조 프레임으로 기본 **`.xMagneticNorthZVertical`**을 사용한다:

```swift
// iosApp/Sources/Engine.swift:134
let frame: CMAttitudeReferenceFrame = (cfg.headingFrame == .gyro)
    ? .xArbitraryZVertical
    : .xMagneticNorthZVertical
```

`.xMagneticNorthZVertical`은 CoreMotion의 자력계 융합 AHRS 프레임이다. Z축이 연직 상방(중력 역방향)으로 고정되고, X축이 자기 북(magnetic north)을 향한다. 즉 **yaw = 자기 방위각**이며, 자력계 판독값이 attitude quaternion/rotationMatrix에 반영된다. 이는 Android의 `TYPE_GAME_ROTATION_VECTOR`(가속도계+자이로, 자력계 완전 제외)와 가장 중요한 차이점이다 (→ II-B.4, [30-compare-converge.md](./30-compare-converge.md) 참조).

```swift
// iosApp/Sources/Engine.swift:138-142
let r = dm.attitude.rotationMatrix
let m: [Double] = [r.m11, r.m21, r.m31, r.m12, r.m22, r.m32, r.m13, r.m23, r.m33]
let r9 = KotlinFloatArray(size: 9)
for i in 0..<9 { r9.set(index: Int32(i), value: Float(m[i])) }
engine.onGameRotation(tNs: t, r9: r9)
```

attitude.rotationMatrix를 r9 배열로 변환하여 공통 엔진의 `onGameRotation`에 주입하므로, 자력계 오염된 yaw가 그대로 EqNIO 입력 파이프라인(GravityAlignedResampler → EqO2Preprocess)으로 전달된다.

### 가속도계 — 부호 반전

iOS는 가속도를 `-(userAcceleration + gravity) × g`로 부호 반전하여 주입한다 (`Engine.swift:143-148`). Android는 원시 부호를 그대로 사용하므로, 축/카이랄리티 불일치 가능성이 있다 (2순위 가설, `docs/ios-drift-rootcause.md §5` 참조).

### IMU 레이트 비교

| 항목 | iOS | Android |
|---|---|---|
| 회전 소스 | CoreMotion deviceMotion, `.xMagneticNorthZVertical`(자력계 융합) | `TYPE_GAME_ROTATION_VECTOR`(자력계 제외) |
| 가속도계 레이트 | 200 Hz (deviceMotionUpdateInterval = 1/200) | `SENSOR_DELAY_FASTEST` (~200 Hz+) |
| 자이로스코프 레이트 | 200 Hz (deviceMotion 통합) | `TYPE_GYROSCOPE_UNCALIBRATED`, `SENSOR_DELAY_FASTEST` |
| 자력계 attitude 융합 | **O (자북 앵커)** | **X (게임 회전, 자력계 없음)** |

---

## II-B.2 자기 3겹

코어 공통부는 I-3 참조.

iOS PoC에는 Android에 없는 자기 의존 보정이 3겹 누적되어 있다. 이는 `docs/ios-drift-rootcause.md §1, §2`에서 근본원인으로 식별된 구조적 차이다.

### ① attitude 자력계 융합 (헤딩 채널)

앞절(II-B.1)에서 기술한 `.xMagneticNorthZVertical` 프레임이 **yaw를 자기 북에 고정**한다. 실내 자기 이상(철골·배선·전자기기)이 이 yaw를 오염시키며, 오염된 yaw가 EqNIO 입력에 "기준"으로 전파된다. **Android는 `TYPE_GAME_ROTATION_VECTOR`를 사용하므로 이 채널이 완전 면역**이다.

### ② MagneticLocator (절대위치 락)

`Engine.swift:29-34, 155-157`에서 `MagneticLocator`가 활성화된다:

```swift
// Engine.swift:29-34
private lazy var magLocator: MagneticLocator? = {
    guard let url = Bundle.main.url(forResource: "mag_reference", withExtension: "json"),
          let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }
    return MagneticLocator(ref: MagReference.companion.fromJson(text: text),
                           windowM: 3.0, minMatchM: 2.0, emitStepM: 0.5,
                           gateUt: 5.0, sigmaM: 0.6, candStepM: 0.1)
}()

// Engine.swift:155-157
if cfg.useMagneticLocator, self.located, let loc = self.magLocator,
   let fix = loc.onSample(x: self.lastEstX, y: self.lastEstY, wmag: wmag, tNs: self.lastEstNs) {
    engine.onAbsolutePosition(x: fix.x, y: fix.y, sigmaM: fix.sigmaM, tNs: fix.tNs)
}
```

`MagneticLocator`는 보정 자기장 크기(`dm.magneticField.field`에서 산출한 `wmag`)를 사전 수집한 자기 지도(`mag_reference.json`)와 매칭하여 절대 위치 픽스를 주입한다. 자기 지도가 오래됐거나 환경이 달라지면 틀린 좌표로 입자 필터를 스냅시켜 드리프트를 증폭할 수 있다. **Android(`indoorpos-android`)에는 `MagneticLocator` 클래스 호출이 전무**하다.

### ③ HeadingOffsetMap (자북 편각 시드)

`Engine.swift:94-97, 111`에서 `HeadingOffsetMap`을 로드하여 엔진의 `headingOffsetMap`으로 주입한다:

```swift
// Engine.swift:94-97
private func loadHeadingOffset() -> HeadingOffsetMap? {
    guard let url = Bundle.main.url(forResource: "heading_offset", withExtension: "json"),
          let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }
    return HeadingOffsetMap.companion.fromJson(text: text)
}

// Engine.swift:111
headingOffsetMap: cfg.useHeadingOffset ? loadHeadingOffset() : nil,
```

`HeadingOffsetMap`은 공간 위치별 자북 편각(heading offset)을 저장한 맵으로, 엔진이 initial heading seed 보정에 사용한다. 맵이 stale 상태이면 systematic 헤딩 바이어스를 유발한다. **Android에는 이 오브젝트의 인스턴스화가 없다** (`docs/ios-drift-rootcause.md §1` 코드 증거표 참조).

### 3겹 비교 요약

| 자기 의존 채널 | iOS | Android | 드리프트 함의 |
|---|---|---|---|
| attitude 자력계 융합(yaw 채널) | `.xMagneticNorthZVertical` **O** | `TYPE_GAME_ROTATION_VECTOR` **X** | 실내 자기 이상 → yaw 오염 |
| MagneticLocator 절대 락 | **활성** (`Engine.swift:29-34`) | **없음** | 틀린 자기 맵 → 오좌표 스냅 |
| HeadingOffsetMap 편각 시드 | **로드/적용** (`Engine.swift:94-97`) | **없음** | stale 시 systematic 바이어스 |

---

## II-B.3 콜드스타트 견고화

코어 공통부는 I-3 참조.

### 정지샷 게이트 — 블러↓, PnP↑

VPS 콜드스타트 촬영 전 `captureWhenSteady` 함수(`Engine.swift:163-175`)가 자이로 안정을 확인한 뒤 셔터를 누른다:

```swift
// Engine.swift:162-174
/// 자이로가 임계(0.3 rad/s) 아래로 안정되면 촬영, 최대 1.5s 후엔 그냥 촬영(행 방지).
private func captureWhenSteady(_ done: @escaping (Data?, Double?) -> Void) {
    self.gyroMag = 1.0   // 게이트 no-op 방지: 초기값 0.0이면 첫 poll이 즉시 통과하므로 임계 이상으로 리셋
    let start = ProcessInfo.processInfo.systemUptime
    func poll() {
        if self.gyroMag < 0.3 || ProcessInfo.processInfo.systemUptime - start > 1.5 {
            self.camera.capture(done)
        } else {
            self.ui { self.text = "📷 흔들림 없이 잠깐 고정…" }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { poll() }
        }
    }
    poll()
}
```

- **gyroMag 임계**: `|ω| < 0.3 rad/s` (자이로 크기, `Engine.swift:26, 151`)
- **타임아웃**: 최대 1.5 s 대기 후 강제 촬영(무한 대기 방지)
- **초기값 강제 리셋**: `gyroMag = 1.0`(임계 이상)으로 초기화하여 첫 poll이 자이로 값 갱신 전에 즉시 통과하는 no-op 방지 (`Engine.swift:164`)
- **효과**: 블러 감소 → VPS PnP 인라이어 수 증가 → 헤딩 추정 신뢰도 향상

`Engine.swift:26`에서 `gyroMag`는 `startMotion` 내 모션 콜백에서 매 IMU 샘플마다 갱신된다(`Engine.swift:149-151`). 정지샷 게이트는 최신 자이로 크기를 실시간으로 확인하므로 손 흔들림을 효과적으로 배제한다.

### t_photo — 셔터시각 전달

`Engine.swift:45-55`에서 `captureWhenSteady`는 `tPhotoSec`(셔터 시각, `ProcessInfo.systemUptime` 클럭)을 콜백으로 반환하고, VPS 응답 수신 시 이를 엔진 타임스탬프로 변환하여 `onVpsFix` / `onAbsolutePosition`에 전달한다:

```swift
// Engine.swift:55
let tNs = Int64(tPhotoSec * 1_000_000_000.0)   // 셔터 시각(엔진 링버퍼 키와 동일 클럭)
```

이로써 VPS 서버 왕복 지연(~수 초) 동안 IMU 링버퍼에 쌓인 데이터를 **셔터 시각 기준으로 정렬**하여 콜드스타트 헤딩 앵커의 타임스탬프 오차를 제거한다. 이전 버전은 VPS 응답 도착 시각(`NOW`)을 사용하여 타임스탬프 불일치가 발생했다.

### VPS 응답 시간 개선 — ~18 s → < 5 s

VPS 서버 측 모델 영속화(요청당 재로딩 제거)로 응답 지연이 대폭 단축되었다. 세부 내용은 [10-core-capture-vps.md](./10-core-capture-vps.md) (Part I-2) 참조.

---

## II-B.4 iOS 드리프트 근본원인

코어 공통부는 I-3 참조.

이 절은 `docs/ios-drift-rootcause.md`의 진단 내용을 요약한다. **상태: 근본원인 가설 확정 대기 (코드 수정 전 검증 필요, 신뢰도 ~80%)**

```mermaid
flowchart TD
    MAG["Magnetometer"] --> CM[".xMagneticNorthZVertical<br/>(yaw fused with indoor magnetic anomaly)"]
    CM --> R9["rotation matrix r9"]
    R9 --> PIPE["resampler / EqNIO / PF"]
    PIPE --> DRIFT["amplified heading drift (A-B-A)"]
    ANDROID["Android TYPE_GAME_ROTATION_VECTOR<br/>(no magnetometer)"] --> NODRIFT["no contamination"]
```
> 그림: iOS 드리프트 근본원인 — 자력계 오염 경로와 Android 비교.

![Uncorrected heading drift at 4.5 deg/min: heading error (deg, blue) and lateral error (m, red dashed) vs time 0–180 s; vertical markers at 90 s and 120 s re-anchor window](./figures/heading_drift.png)
> 그림: 보정 없는 헤딩 드리프트 정량화 — **예시 곡선(ILLUSTRATIVE)**. 자이로 드리프트율 4.5 deg/min 가정(실측 스마트폰 MEMS 범위). 파란 실선: 헤딩 오차(deg), 빨간 점선: 1 m/s 보행 시 측방 누적오차(m). 녹색 세로 점선: 재앵커 설계 목표 구간(90–120 s). 120 s 시 헤딩 오차 약 9 deg → 측방오차 수 m 규모.

### 증상

Android와 동일한 A-B-A 보행 테스트(A=시작 물리 위치, B=반환점, A로 복귀)에서 **iOS만 드리프트가 유독 심하다**. 공통 KMP 엔진을 사용하므로 차이는 플랫폼별 센서 입력 브리지에서 기인한다.

### 핵심 메커니즘 — 자력계 융합 attitude가 실내 자기 교란을 yaw로 흡수

iOS는 `.xMagneticNorthZVertical`(자력계 융합) attitude로 yaw를 자기 북에 고정하고, Android는 `TYPE_GAME_ROTATION_VECTOR`(자력계 완전 제외)로 yaw를 순수 자이로+가속으로 추정한다. 실내 자기 이상(철골·배선·전자기기)이 iOS yaw를 **계단식 excursion**(부드러운 드리프트가 아닌 불연속적 점프)으로 오염시키고, 이 오염된 yaw가 resampler → EqNIO → PF의 "기준"으로 전파되어 A-B-A 복귀오차(헤딩 바이어스에 가장 민감)를 키운다.

코드 증거 (`docs/ios-drift-rootcause.md §1`):

| 주장 | 위치 |
|---|---|
| iOS 자력계 융합 attitude | `iosApp/Sources/Engine.swift:134` (`.xMagneticNorthZVertical`) |
| iOS r9 = attitude.rotationMatrix → 엔진 | `iosApp/Sources/Engine.swift:138-142` |
| Android game-rotation (자력계 없음) | `core-positioning/src/androidMain/.../source/SensorManagerSource.kt:22,73-75` |
| iOS MagneticLocator 절대 fix | `iosApp/Sources/Engine.swift:29-34, 155-157` |
| iOS HeadingOffsetMap 로드/시드 | `iosApp/Sources/Engine.swift:94-97, 111` |

### 트레이드의 역전 — 왜 실내에서만 나빠지나

`.xMagneticNorthZVertical`은 *원래는* 자력계로 자이로 드리프트를 잡는 좋은 선택이다. **자기적으로 깨끗한 환경에서는** gyro-only보다 낫다. 실내에서 이 트레이드가 뒤집힌다:

> A-B-A 시간스케일에서 **자이로 드리프트 < 자기 교란 오차**이므로, 자력계를 믿는 iOS가 자이로만 적분하는 Android보다 나빠진다.

이것이 "iOS만 심함"의 정확한 메커니즘이며, 기존 cross-core 결론("실내 자기 보정 기여 ~0, 헤딩 못 고침")과 합치한다 (MEMORY: Fusion cross-core 결과).

### 자기 3겹 누적 효과

"iOS가 더 심하다"는 우연이 아니라, **실내에서 해로운 자기 신호가 전부 iOS에만 켜져 있는** 구조적 결과다 (`docs/ios-drift-rootcause.md §2`):

1. attitude 자력계 융합 — 헤딩 채널 오염
2. MagneticLocator 절대 락 — 틀린 자기 맵 → 오좌표 스냅으로 드리프트 증폭
3. HeadingOffsetMap 편각 시드 — stale → systematic 헤딩 바이어스

### 권고 — `.xArbitraryZVertical` 교체 (현재 미적용)

권고 수정사항은 **개발 담당 전달용**이며, 코드 수정 전 §3 확인 테스트(gyro-only 헤딩 재적분 등) 검증 필요 (`docs/ios-drift-rootcause.md §4`):

1. **[1순위]** iOS attitude 프레임 교체: `.xMagneticNorthZVertical` → **`.xArbitraryZVertical`** (자력계 완전 제외 = Android `TYPE_GAME_ROTATION_VECTOR` 등가). 기대효과: iOS 드리프트가 Android 수준으로 수렴.

   > ⚠️ **`.xArbitraryCorrectedZVertical`은 사용 금지** — 이 프레임은 내부적으로 자력계를 재도입하여 yaw를 "보정"하므로, 우리가 배제하려는 바로 그 신호를 재도입한다.

2. **[2순위]** iOS-only 자기 의존 ablation: MagneticLocator · HeadingOffsetMap · magUpdate를 venue 로그에서 ON/OFF 비교 후 down-rank/제거.

---

## II-B.5 iOS 실측

코어 공통부는 I-3 참조.

### 현황

| 항목 | 상태 | 출처/비고 |
|------|------|-----------|
| 신경 DR ATE (cross-core 리플레이) | ✅ **2.7 m / 5.8%** | MEMORY: Fusion cross-core 결과 — iOS 캡처→공통 KMP 엔진 실측 |
| 자기 보정 기여 (실내) | ✅ **기여 없음** | MEMORY: Fusion cross-core 결과 — 양 플랫폼 공통 |
| A-B-A iOS vs Android 드리프트 비교 | (측정 예정) | `docs/ios-drift-rootcause.md §3` 확인 테스트 미수행 |
| `.xArbitraryZVertical` 교체 후 드리프트 | (측정 예정) | 권고 미적용; 교체 후 동일 A-B-A 재측정 필요 |
| VPS 콜드스타트 응답 지연 | ✅ **~18 s → < 5 s** | 모델 영속화 (I-2 전방참조); 정지샷 게이트 도입 후 PnP 인라이어 수 개선 |
| iOS EqNIO golden-replay 통과 여부 | (측정 예정) | 2순위 가설(축/부호) 기각 여부 확인 필요 |

### A-B-A iOS > Android 드리프트 (정량)

현재 두 플랫폼 간 A-B-A 닫힘오차 정량 비교 수치는 기록되어 있지 않다(측정 예정). 코드 분석 기반 근본원인 진단은 II-B.4에서 완료되었으며, 정량 비교는 동일 venue에서 A-B-A 로그 수집 후 [30-compare-converge.md](./30-compare-converge.md)에서 업데이트 예정이다.
