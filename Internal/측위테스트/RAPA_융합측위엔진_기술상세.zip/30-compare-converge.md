# III. 플랫폼 비교 · 수렴 · 향후

> **버전** v0.1-draft · **날짜** 2026-06-25 · **상태** 초안
> 이 파일(Part III)은 Android(II-A)와 iOS(II-B) 플랫폼 프로파일을 단일 비교 매트릭스로 대조하고, 기전 분기 원인과 수렴 로드맵을 기술하며, 향후 고도화 / 수정 여지를 정리한다. 개별 플랫폼 상세는 [20-platform-android.md](./20-platform-android.md)(II-A), [21-platform-ios.md](./21-platform-ios.md)(II-B)를 참조.

---

## III-1 플랫폼 비교 매트릭스

아래 표는 Android·iOS 플랫폼의 측위 관련 핵심 속성을 나란히 대조한다. 각 셀의 출처는 II-A, II-B에서 코드 수준으로 검증된 값을 그대로 인용하였다.

| 속성 | Android | iOS | 드리프트 함의 |
|---|---|---|---|
| **회전 소스** | `TYPE_GAME_ROTATION_VECTOR` — 가속도계+자이로, **자력계 완전 제외** | `CMDeviceMotion`, `.xMagneticNorthZVertical` — **자력계 융합 AHRS** | Android yaw는 자기 이상에 면역; iOS yaw는 실내 자기 이상이 계단식 excursion으로 오염 (→ A-B-A 복귀오차 증폭) |
| **attitude 자력계 융합 여부** | **X** (게임 회전, 자력계 없음) | **O** (자기 북 앵커, yaw = 자기 방위각) | iOS만 실내 자기 이상에 노출; 자기 깨끗한 환경에서는 iOS가 유리하나 실내에서 트레이드 역전 [ios-drift-rootcause §2] |
| **자기 레이어 겹 수** | **0겹** (MagneticLocator 없음, HeadingOffsetMap 없음, magUpdate 앱 미연결) | **3겹** (① attitude 자력계 융합, ② MagneticLocator 절대 락, ③ HeadingOffsetMap 편각 시드) | iOS에만 해로운 자기 신호 3개 중첩 → "iOS만 심함"의 구조적 원인 [ios-drift-rootcause §1] |
| **FP (BLE/WiFi) 상태** | **green-field** — BLE/WiFi 서베이 미구현; `onAbsolutePosition` 주입 인터페이스는 준비됨 | **green-field** — BLE/WiFi 서베이 미구현; `onAbsolutePosition` 주입 인터페이스 공유 | 둘 다 미연결; 향후 Android 우선 추가 권고 (OS API 개방성 차이로) |
| **OS FP API 개방성** | **더 개방적** — `BluetoothLeScanner`, `WifiManager` (raw RSSI 접근 허용) | **제한적** — third-party WiFi RSSI raw scan을 OS가 차단 (iOS 13+ CNA 정책); BLE는 가능하나 백그라운드 제약 | FP 로드맵상 Android를 선행 플랫폼으로 권고하는 구조적 이유 |
| **자기 FP (GP 자기맵)** | `AndroidMapLoader.loadBundledMagMap()` 코드 존재, **앱 레이어 미연결** (팩토리 호출 없음) | `MagneticLocator` / `HeadingOffsetMap` 활성, `mag_reference.json` · `heading_offset.json` 번들 | Android는 코드는 있으나 미사용; iOS는 과도하게 활성화 — 각각 반대 방향의 미조정 |
| **VPS 연결** | VPS 클라이언트 **미구현** (Android VPS 클라이언트 ⏳ 예정) | **활성** — 정지샷 게이트(`captureWhenSteady`, gyroMag < 0.3 rad/s), t_photo 셔터시각 앵커, 응답 ~18 s → < 5 s (모델 영속화) | iOS만 현재 E2E VPS 측위 루프 완성; Android는 별도 구현 필요 |
| **GT 앵커 방식** | ARCore VIO 포즈 (x, z → 바닥 평면) | ARKit VIO (RapaCapture) → COLMAP prior | 둘 다 VIO 기반; 복수 세션 정합은 N점 상사변환(Umeyama 1991) |
| **IMU 레이트** | `SENSOR_DELAY_FASTEST` (~200 Hz+, accel/gyro); rotation 계열 `SENSOR_DELAY_GAME` (~50 Hz) | CoreMotion deviceMotion 200 Hz (`deviceMotionUpdateInterval = 1/200`) | GravityAlignedResampler 200 Hz 균일 그리드에서 양 플랫폼 정렬 |
| **신경 DR ATE** | (측정 예정) — KMP 공통 엔진 cross-core 리플레이 기준 2.7 m / 5.8% 참조 가능 | ✅ **2.7 m / 5.8%** (iOS 캡처→공통 KMP 엔진, cross-core 리플레이) | KMP 엔진 공통부 성능; Android 전용 실측은 별도 필요 |
| **자기 보정 기여 (실내)** | ✅ **기여 없음** (양 플랫폼 공통 cross-core 결과) | ✅ **기여 없음** (양 플랫폼 공통 cross-core 결과) | 실내 자기 보정은 양 플랫폼 모두에서 효과 없음 확인 |

### 요약: 핵심 구조 차이

두 플랫폼의 측위 동작이 달라지는 원인은 크게 두 가지다.

1. **회전 소스의 자력계 포함 여부**: Android `TYPE_GAME_ROTATION_VECTOR`는 자력계를 완전히 배제하므로 실내 자기 이상에 면역이며, yaw는 순수 자이로 적분으로 부드럽게 드리프트한다. iOS `.xMagneticNorthZVertical`은 자력계로 yaw를 자기 북에 고정하므로 실내 자기 이상이 비연속 excursion으로 yaw를 오염시키고, 이 오염이 EqNIO 입력 → PF predict 기준으로 전파된다.

2. **OS 수준 FP API 정책**: iOS는 third-party WiFi RSSI raw scan을 시스템이 차단하여(iOS 13+ CNA, NEHotspotConfigurationManager 정책) BLE/WiFi 기반 FP 수집이 구조적으로 더 어렵다. Android는 `BluetoothLeScanner` · `WifiManager`를 통해 더 개방적으로 접근할 수 있어 FP 수집·융합 구현이 용이하다.

---

## III-2 기전 분기 원인 & 수렴 로드맵

### 분기 원인 분석

동일한 KMP `commonMain` 엔진을 사용하는데도 두 플랫폼이 서로 다른 드리프트 패턴을 보이는 이유는 **센서 입력 브리지 레이어**의 차이에서 비롯된다.

**1순위 원인 — 자력계 융합 attitude (신뢰도 ~80%)**

iOS `Engine.swift:134`의 attitude 참조 프레임 기본값이 `.xMagneticNorthZVertical`이다. 이 프레임에서 yaw = 자기 방위각이므로, `attitude.rotationMatrix`를 r9로 변환하여 `onGameRotation`에 주입하는 순간 자력계 오염 yaw가 그대로 EqNIO의 "기준 방향"으로 입력된다. GravityAlignedResampler는 이 r9를 참조로 중력 정렬을 수행하므로, 오염된 yaw는 EqNIO 전처리 단계(EqO2Preprocess)의 회전 군 O(2) 분해에도 그대로 반영된다.

실내 자기 이상은 위치마다 **계단식 excursion**(부드러운 드리프트가 아닌 불연속 점프)을 발생시킨다. 이것이 A-B-A 복귀 오차를 크게 키우는 이유다: A→B 아웃바운드에서 yaw가 한 방향으로 excursion되고, B→A 리턴에서 반대 excursion이 정확히 상쇄되지 않으면 복귀 시 각도 오차가 닫히지 않는다 [ios-drift-rootcause §2].

**2순위 원인 — 자기 의존 3겹 누적**

iOS에만 MagneticLocator 절대 락과 HeadingOffsetMap 편각 시드가 추가로 활성화되어 있다. 자기 맵이 stale하거나 환경이 변했을 때 MagneticLocator가 엉뚱한 좌표로 입자 필터를 스냅시키고, HeadingOffsetMap이 systematic 헤딩 바이어스를 유발한다. Android에는 이 두 레이어가 없어 이 경로의 드리프트 증폭이 없다 [ios-drift-rootcause §1].

**트레이드의 역전 — 왜 실내에서만 iOS가 나빠지나**

`.xMagneticNorthZVertical`은 자기적으로 깨끗한 환경에서는 자력계로 자이로 드리프트를 잡는 좋은 선택이다. 실내에서 이 트레이드가 뒤집힌다:

> A-B-A 시간스케일에서 **자이로 드리프트 < 자기 교란 오차**이므로, 자력계를 믿는 iOS가 자이로만 적분하는 Android보다 나빠진다.

이 결론은 cross-core 실측("실내 자기 보정 기여 ~0")과 정확히 합치한다 [Fusion cross-core 결과].

---

### 수렴 로드맵

두 플랫폼의 기전을 수렴시키는 최소 변경 경로는 다음과 같다.

```mermaid
flowchart LR
    CUR["Current: iOS magnetometer-fused + 3 magnetic layers<br/>/ Android game-rotation"]
    CUR --> SA["Step A: iOS .xArbitraryZVertical"]
    SA --> SB["Step B: drop iOS magnetic layers"]
    SB --> CONV["Converged: identical mechanism"]
```
> 그림: 수렴 로드맵 — iOS 자력계 의존 제거를 통한 양 플랫폼 기전 통일 경로.

#### 단계 A — iOS attitude 프레임 교체 (✅ 권고, ⏳ 미적용)

`Engine.swift:134`의 기본 attitude 참조 프레임을 `.xMagneticNorthZVertical`에서 **`.xArbitraryZVertical`**로 교체한다. 이렇게 하면 iOS yaw 소스가 Android `TYPE_GAME_ROTATION_VECTOR`와 동등한 자이로+가속 전용 추정이 된다.

> ⚠️ **`.xArbitraryCorrectedZVertical`은 사용 금지** — 이 프레임은 CoreMotion이 내부적으로 자력계를 재도입하여 yaw를 "보정"하므로, 배제하려는 바로 그 신호를 재도입한다. 이름의 "Corrected"가 혼동을 유발하므로 주의가 필요하다 [21-platform-ios.md §II-B.4].

교체 후 기대 효과: iOS A-B-A 복귀오차가 Android 수준으로 수렴.

#### 단계 B — iOS 자기 3겹 ablation (⏳ 예정, 검증 후)

`cfg.useMagneticLocator` / `cfg.useHeadingOffset` 플래그를 비활성화하고, 동일 venue A-B-A 로그를 재수집하여 ON/OFF 비교를 수행한다. 결과에 따라 MagneticLocator · HeadingOffsetMap을 down-rank(σ를 키워 PF 영향을 줄임) 또는 제거한다.

#### 검증 절차 — A-B-A gyro-only 오프라인 재생

단계 A 코드 수정 전에 **기존 iOS IMU 로그를 gyro-only 헤딩 재적분(자력계 제외)으로 오프라인 재생**하여 드리프트가 Android 수준으로 감소하는지 확인한다. 이것이 가장 빠른 판별 방법이다 [ios-drift-rootcause §3]:

1. `§3-(3) gyro-only 재생`: 동일 iOS IMU 로그를 attitude 자력계 없이 재적분 → 드리프트 감소 여부 확인 (결정적 판별)
2. `§3-(1) A-B-A 닫힘오차 분해`: 오차가 각도(heading) 지배인지 스케일 지배인지 확인 → 본 가설(자력계 원인) 강화 또는 2순위(가속 부호)로 전환
3. (확정 시) 단계 A 적용 + 동일 A-B-A 재측정으로 회귀 확인

수렴 완료 조건: iOS · Android 동일 venue A-B-A 닫힘오차 RMSE가 통계적으로 동등 (정량 비교 수치는 측정 예정).

---

## III-3 한계 · 리스크 · 향후 (DL 도입 여지)

```mermaid
flowchart TD
    ROOT["DL levers"]
    ROOT --> AN["adopt-now: conformal gate<br/>/ position-OOSM<br/>/ drop magnetic"]
    ROOT --> PI["pilot: EqNIO covariance (NLL retrain)<br/>/ LightGlue confidence<br/>/ floorplan match"]
    ROOT --> SK["skip: AirIMU<br/>/ multimodal transformer<br/>/ learned smoother"]
```
> 그림: DL 도입 여지 분류 — adopt-now·pilot·skip 세 티어로 정리한 레버.

### 현재 시스템 한계

| 한계 | 내용 | 관련 파일 |
|---|---|---|
| 헤딩(yaw) 공분산 미출력 | EqNIO O(2) 현재 모델(`eqnio_o2.onnx`)은 변위 `[vx, vy]` 2차원만 출력; per-step covariance head 없음 | [11-core-fusion.md §I-3.1] |
| 위치 OOSM 미처리 | VPS 지연 fix(~20 s)가 도착 시각 입자 분포에 적용됨; 셔터시각 헤딩 역추정만 수행(부분 OOSM) | [11-core-fusion.md §I-3.4] |
| 자기 보정 실내 무효 | cross-core 실측에서 자기 보정 기여 ~0 확인; 현재 자기 레이어는 iOS에서 드리프트를 오히려 증폭 | [20-platform-android.md §II-A.4], [21-platform-ios.md §II-B.5] |
| Android VPS 미구현 | Android 플랫폼 VPS 클라이언트 없음 → E2E 측위 루프 미완성 | [20-platform-android.md §II-A.4] |
| BLE/WiFi FP 미구현 (양 플랫폼) | 두 플랫폼 모두 green-field; VPS 절대 fix 빈도가 낮은 구간에서 헤딩 드리프트를 제어할 수단 부재 | [20-platform-android.md §II-A.2], [21-platform-ios.md §II-B.1] |

### DL 도입 여지 분석

#### 핵심 관점 — "새 모델 얹기"가 아닌 레버 집중

DL 개선의 레버는 **기존 EqNIO에 학습 covariance를 살리고 conformal calibration으로 재보정하여 PF predict 노이즈 모델과 VPS spatial gate에 연결하는 것**에 집중되어 있다. 완전히 새로운 모델을 도입하는 방향은 GT 라벨 부재, 실시간 예산, 현재 보유 데이터 제약을 감안할 때 우선순위가 낮다.

**보유 데이터 현실:**
- 보유: 비라벨 IMU + VPS survey GT (위치·헤딩 앵커)
- 부재: mocap 또는 외부 ground-truth (ATE 라벨 생성 불가)

이 제약이 아래 레버 분류의 핵심 필터다.

---

#### Adopt-now — 기존 데이터·코드로 즉시 배선 가능

**① conformal 재보정을 VPS gate에 배선**

현재 `ConformalGate` 클래스가 코드에 이미 존재하나 PF predict σ 결정과 VPS spatial gate에 완전히 배선되지 않은 상태다. Conformal prediction(inductive CP)은 학습 데이터 없이 칼리브레이션 세트만으로 보정이 가능하며 [Vovk 2005], EqNIO 잔차의 empirical quantile을 게이트 임계값으로 변환할 수 있다. 구현 경로: survey GT 로그에서 EqNIO 변위 잔차를 수집 → nonconformity score 분포 구축 → VPS gate의 `absFixGateSigma` 적응화.

**② position-OOSM ring-buffer**

Bar-Shalom B-l1 알고리즘[Bar-Shalom 2002]에 따른 per-particle 상태 스냅샷 링버퍼 구현이다. DL이 아닌 고전 통계 방법이지만 현재 위치 OOSM 미처리 한계를 직접 해소한다. VPS 지연 fix(~20 s)를 셔터시각 입자 분포에 적용하면 N_eff 붕괴 위험을 줄이고 VPS 픽스 수용률을 높인다. 예산: 2,000 입자 × ~1,000 스텝 × 4바이트 × 3 (x, y, θ) ≈ 수십 MB; 모바일에서 허용 범위 검토 필요.

**③ magnetic 레이어 down-rank / 삭제**

cross-core 실측 결과 및 iOS 드리프트 분석 결과 자기 레이어가 실내에서 기여 없음 또는 해로움이 확인되었다. iOS `cfg.useMagneticLocator = false` · `cfg.useHeadingOffset = false`로 3겹 자기 의존을 제거하고, A-B-A ablation으로 효과를 정량 확인한다. Android는 자기맵 미연결 상태를 유지한다.

---

#### Pilot — 연구 가치 있으나 추가 작업 필요

**④ EqNIO 학습 covariance (NLL stage 재학습 + 재export)**

현재 `eqnio_o2.onnx`에는 covariance head가 없다("출력 un-prune"이 아님 — ONNX에 해당 출력 텐서가 없음). per-step covariance를 얻으려면 EqNIO 원 학습 코드에 **NLL(Negative Log Likelihood) loss head를 추가하여 재학습하고 ONNX로 재export**해야 한다. 학습에는 변위 GT가 필요하며 보유 VPS survey GT로 유사 라벨 생성이 가능하다(정밀 mocap 대비 부정확하지만 σ 추정 학습에는 충분할 수 있음). 학습된 covariance가 PF `motionSigma` 상수를 대체하면 지형·보행 패턴별 적응 예측 노이즈가 가능해진다 [Liu 2020, TLIO].

**⑤ LightGlue per-match confidence 재사용**

현재 VPS PnP 단계에서 LightGlue[Lindenberger 2023]의 per-match confidence score를 폐기하고 RANSAC inlier 수만 사용한다. 이 confidence를 PnP 잔차 가중치로 활용하거나 VPS 픽스 σ를 동적으로 결정하는 데 재사용하면 VPS gate 정밀도가 향상될 수 있다. 구현 경로: `vps/localize.py`의 match score를 `VpsFix.sigma` 결정 로직에 연결.

**⑥ floorplan map-matching**

도면 벡터(복도 중심선, 방 경계)를 입자 업데이트에 구조적으로 활용하는 map-matching이다. 현재 `WallMap`·`CoverageMask`는 walkable manifold 제약에 집중하나, 복도 중심선 snap이나 room transition 모델을 추가하면 자이로 적분 측방 오차가 자연스럽게 교정된다. 보유 도면 데이터(RoomPlan / CAD 평면도)가 있으면 바로 적용 가능하며, DL 없이 구현 가능한 고전 방법이다.

---

#### Watch / Skip — 현재 조건에서 우선순위 낮음

**AirIMU (Skip — GT orientation 부재)**

AirIMU는 orientation GT가 있어야 학습할 수 있다(mocap 기반 GT 필요). 보유 데이터(비라벨 IMU + VPS survey GT)로는 orientation GT 생성이 불가하므로, 현 시점에서 Skip. VPS 누적 GT가 충분히 쌓이면 revisit 가능.

**iMoT / multimodal transformer (Skip — GT 라벨 필요 또는 실시간 예산 초과)**

입력 데이터 각 모달리티(IMU, 카메라, 자기)를 공동 임베딩하는 transformer 구조는 학습을 위한 정밀 GT 라벨이 필요하며, 추론 지연이 ONNX 경량 모델 대비 수 배 이상 증가한다. 실시간 측위의 10–50 ms 예산 내 실행이 어려워 Skip.

**DiffPF / learned smoother (Skip — GT 라벨 필요)**

PF 업데이트 또는 smoother를 학습 기반으로 대체하는 방법은 PF 궤적 GT가 필요하며, 현재 비라벨 환경에서 self-supervised 변형도 검증되지 않았다. 실시간 PF 대비 계산 비용도 큰 편이어서 현 시점 Skip.

---

### 종합 우선순위

| 티어 | 레버 | 데이터 요구 | 예상 효과 |
|---|---|---|---|
| **adopt-now** | conformal VPS gate 배선 | 보유 VPS survey GT | VPS 픽스 수용률 향상, 조기 배선 가능 |
| **adopt-now** | position-OOSM ring-buffer | 없음 (고전 알고리즘) | VPS 지연 fix N_eff 붕괴 감소 |
| **adopt-now** | magnetic 레이어 down-rank/삭제 | 없음 (플래그) | iOS 드리프트 즉시 개선 예상 |
| **pilot** | EqNIO NLL 재학습 + 재export | VPS GT 유사 라벨 | PF motionSigma 적응화 |
| **pilot** | LightGlue confidence 재사용 | 없음 (VPS 파이프라인 내) | VPS fix σ 동적화 |
| **pilot** | floorplan map-matching | 도면 데이터 | 측방 드리프트 구조적 교정 |
| **skip** | AirIMU | mocap GT 필요 | — |
| **skip** | iMoT / DiffPF / learned smoother | 정밀 GT 필요 + 실시간 예산 초과 | — |
