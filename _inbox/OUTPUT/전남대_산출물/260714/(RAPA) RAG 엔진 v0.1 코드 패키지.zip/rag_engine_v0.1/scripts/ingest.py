#!/usr/bin/env python3
"""고정 코퍼스를 독립 Chroma 컬렉션에 인제스트한다."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from rag_v01.config import EXPECTED_DOCUMENT_COUNT  # noqa: E402
from rag_v01.embedding import embed_texts  # noqa: E402
from rag_v01.store import get_collection  # noqa: E402

CORPUS_PATH = PROJECT_ROOT / "data" / "sample" / "corpus.jsonl"


def load_corpus(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as corpus_file:
        for line_number, line in enumerate(corpus_file, start=1):
            if not line.strip():
                continue
            record = json.loads(line)
            if set(record) != {"id", "document", "metadata"}:
                raise ValueError(f"{line_number}행의 필드 구성이 올바르지 않습니다.")
            if not isinstance(record["id"], str) or not record["id"]:
                raise ValueError(f"{line_number}행의 id가 올바르지 않습니다.")
            if not isinstance(record["document"], str) or not record["document"]:
                raise ValueError(f"{line_number}행의 document가 올바르지 않습니다.")
            if not isinstance(record["metadata"], dict):
                raise ValueError(f"{line_number}행의 metadata가 올바르지 않습니다.")
            records.append(record)

    if len(records) != EXPECTED_DOCUMENT_COUNT:
        raise RuntimeError(
            f"코퍼스 건수가 {EXPECTED_DOCUMENT_COUNT}건이어야 합니다: {len(records)}건"
        )
    if len({record["id"] for record in records}) != len(records):
        raise RuntimeError("코퍼스 id가 중복되었습니다.")
    return records


def main() -> None:
    records = load_corpus(CORPUS_PATH)
    embeddings = embed_texts([record["document"] for record in records])
    collection = get_collection()
    collection.upsert(
        ids=[record["id"] for record in records],
        documents=[record["document"] for record in records],
        metadatas=[record["metadata"] for record in records],
        embeddings=embeddings,
    )
    document_count = collection.count()
    if document_count != EXPECTED_DOCUMENT_COUNT:
        raise RuntimeError(
            f"컬렉션 건수가 {EXPECTED_DOCUMENT_COUNT}건이어야 합니다: {document_count}건"
        )
    print(f"인제스트 완료: {len(records)}건 (컬렉션 총 {document_count}건)")


if __name__ == "__main__":
    main()
