"""메인 evidence 컬렉션을 제출용 JSONL 코퍼스로 읽기 전용 추출한다."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

import chromadb


COLLECTION_NAME = "rapa_evidence_cnuh_v1"
EXPECTED_DOCUMENT_COUNT = 29

SCRIPT_PATH = Path(__file__).resolve()
DELIVERABLE_ROOT = SCRIPT_PATH.parents[1]
REPOSITORY_ROOT = SCRIPT_PATH.parents[3]
SOURCE_DB_PATH = REPOSITORY_ROOT / "data" / "chroma_mvp_bge_m3"
OUTPUT_PATH = DELIVERABLE_ROOT / "data" / "sample" / "corpus.jsonl"


def _build_records(payload: dict[str, Any]) -> list[dict[str, Any]]:
    ids = payload.get("ids") or []
    documents = payload.get("documents") or []
    metadatas = payload.get("metadatas") or []

    if not (len(ids) == len(documents) == len(metadatas)):
        raise RuntimeError("컬렉션 반환 필드의 건수가 서로 다릅니다.")
    if len(ids) != EXPECTED_DOCUMENT_COUNT:
        raise RuntimeError(
            f"예상 문서 수는 {EXPECTED_DOCUMENT_COUNT}건이지만 "
            f"실제 반환은 {len(ids)}건입니다."
        )

    records: list[dict[str, Any]] = []
    for document_id, document, metadata in zip(ids, documents, metadatas, strict=True):
        if not isinstance(document_id, str) or not isinstance(document, str):
            raise RuntimeError("모든 문서에는 문자열 id와 document가 필요합니다.")
        if not isinstance(metadata, dict):
            raise RuntimeError(f"문서 {document_id!r}의 metadata가 객체가 아닙니다.")
        records.append(
            {"id": document_id, "document": document, "metadata": metadata}
        )

    # Chroma의 내부 반환 순서와 무관하게 재실행 결과가 동일하도록 ID로 정렬한다.
    return sorted(records, key=lambda record: record["id"])


def _write_jsonl_atomically(records: list[dict[str, Any]]) -> None:
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{OUTPUT_PATH.name}.",
        suffix=".tmp",
        dir=OUTPUT_PATH.parent,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(
            file_descriptor,
            mode="w",
            encoding="utf-8",
            newline="\n",
        ) as temporary_file:
            for record in records:
                temporary_file.write(
                    json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n"
                )
            temporary_file.flush()
            os.fsync(temporary_file.fileno())
        os.replace(temporary_path, OUTPUT_PATH)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def main() -> None:
    client = chromadb.PersistentClient(path=str(SOURCE_DB_PATH))
    collection = client.get_collection(COLLECTION_NAME)
    payload = collection.get(include=["documents", "metadatas"])

    records = _build_records(payload)
    _write_jsonl_atomically(records)
    print(f"코퍼스 export 완료: {OUTPUT_PATH} ({len(records)}건)")


if __name__ == "__main__":
    main()
