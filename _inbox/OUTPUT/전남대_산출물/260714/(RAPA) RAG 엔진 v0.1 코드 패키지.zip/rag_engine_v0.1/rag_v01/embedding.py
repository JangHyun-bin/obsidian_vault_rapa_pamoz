"""BGE-M3 dense 임베딩."""

from __future__ import annotations

import threading
from typing import Any

import numpy as np

from rag_v01.config import EMBEDDING_DEVICES, EMBEDDING_USE_FP16, MODEL_NAME

_model: Any | None = None
_model_lock = threading.Lock()


def resolve_embedding_devices() -> str | list[str] | None:
    configured = EMBEDDING_DEVICES.strip()
    if configured:
        if configured.lower() == "auto":
            return None
        if "," in configured:
            return [device.strip() for device in configured.split(",") if device.strip()]
        return configured

    try:
        import torch

        if torch.cuda.is_available():
            return "cuda:0"
    except Exception:
        pass
    return "cpu"


def get_model() -> Any:
    global _model
    if _model is None:
        with _model_lock:
            if _model is None:
                from FlagEmbedding import BGEM3FlagModel

                _model = BGEM3FlagModel(
                    MODEL_NAME,
                    use_fp16=EMBEDDING_USE_FP16,
                    devices=resolve_embedding_devices(),
                )
    return _model


def embed_texts(texts: list[str]) -> list[list[float]]:
    model = get_model()
    encoded = model.encode(
        texts,
        batch_size=max(1, min(len(texts), 16)),
        max_length=512,
        return_dense=True,
        return_sparse=False,
        return_colbert_vecs=False,
    )
    vectors = encoded["dense_vecs"]
    if isinstance(vectors, np.ndarray):
        return vectors.astype(float).tolist()
    return [list(vector) for vector in vectors]


def embed_query(query: str) -> list[float]:
    return embed_texts([query])[0]
