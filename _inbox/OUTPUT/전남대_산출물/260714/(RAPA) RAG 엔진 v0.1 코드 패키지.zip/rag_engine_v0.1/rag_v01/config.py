"""RAG 엔진 v0.1 실행 설정."""

from __future__ import annotations

import os
from pathlib import Path

# 제출본은 서버 공용 캐시만 사용하고 Hugging Face 네트워크 요청을 차단한다.
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

PROJECT_ROOT = Path(__file__).resolve().parents[1]
COLLECTION_NAME = "rapa_evidence_cnuh_v1"
MODEL_NAME = "BAAI/bge-m3"
EXPECTED_DOCUMENT_COUNT = 29


def env_flag(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def env_port(name: str, default: int) -> int:
    raw_value = os.getenv(name, str(default)).strip()
    try:
        value = int(raw_value)
    except ValueError as exc:
        raise RuntimeError(f"{name}는 정수여야 합니다: {raw_value}") from exc
    if not 20000 <= value <= 22000:
        raise RuntimeError(f"{name}는 할당 범위 20000~22000 안이어야 합니다: {value}")
    return value


def resolve_database_path() -> Path:
    default_path = (PROJECT_ROOT / "data" / "chroma_v01").resolve()
    configured = os.getenv("RAG_V01_DB_PATH", "").strip()
    database_path = Path(configured).expanduser().resolve() if configured else default_path

    # 원본 저장소 안에서 실행할 때 메인 DB로 잘못 쓰는 사고를 차단한다.
    main_database_path = (PROJECT_ROOT.parents[1] / "data" / "chroma_mvp_bge_m3").resolve()
    if database_path == main_database_path:
        raise RuntimeError("RAG_V01_DB_PATH에 메인 Chroma DB를 지정할 수 없습니다.")
    return database_path


PORT = env_port("PORT", 20013)
EMBEDDING_DEVICES = os.getenv("EMBEDDING_DEVICES", "").strip()
EMBEDDING_USE_FP16 = env_flag("EMBEDDING_USE_FP16", False)
DB_PATH = resolve_database_path()
