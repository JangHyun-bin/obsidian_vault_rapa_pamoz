"""Dense top-k 검색과 점수 변환."""

from __future__ import annotations

from typing import Any

from rag_v01.embedding import embed_query
from rag_v01.store import get_collection


class EmptyCollectionError(RuntimeError):
    """인제스트 전 빈 컬렉션을 검색한 경우."""


def chroma_distance_to_similarity(distance: Any) -> float:
    return max(0.0, min(1.0, 1.0 - float(distance)))


def format_results(raw: dict[str, Any]) -> list[dict[str, Any]]:
    documents = raw.get("documents", [[]])[0]
    metadatas = raw.get("metadatas", [[]])[0]
    distances = raw.get("distances", [[]])[0]
    results: list[dict[str, Any]] = []
    for index, (document, metadata, distance) in enumerate(
        zip(documents, metadatas, distances, strict=False),
        start=1,
    ):
        results.append(
            {
                "rank": index,
                "similarity": round(chroma_distance_to_similarity(distance), 4),
                "distance": round(float(distance), 4),
                "document": str(document or ""),
                "metadata": metadata or {},
            }
        )
    return results


def search_dense(query: str, top_k: int) -> list[dict[str, Any]]:
    collection = get_collection()
    if collection.count() == 0:
        raise EmptyCollectionError("인제스트 필요: 검색 컬렉션이 비어 있습니다.")

    query_vector = embed_query(query)
    raw = collection.query(
        query_embeddings=[query_vector],
        n_results=top_k,
        include=["documents", "metadatas", "distances"],
    )
    return format_results(raw)
