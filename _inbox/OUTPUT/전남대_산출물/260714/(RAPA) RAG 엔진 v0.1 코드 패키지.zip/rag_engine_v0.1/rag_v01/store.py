"""독립 Chroma 영속 저장소."""

from __future__ import annotations

from functools import lru_cache
from typing import Any

import chromadb

from rag_v01.config import COLLECTION_NAME, DB_PATH


@lru_cache(maxsize=1)
def get_client() -> chromadb.ClientAPI:
    DB_PATH.mkdir(parents=True, exist_ok=True)
    return chromadb.PersistentClient(path=str(DB_PATH))


@lru_cache(maxsize=1)
def get_collection() -> Any:
    return get_client().get_or_create_collection(COLLECTION_NAME)
