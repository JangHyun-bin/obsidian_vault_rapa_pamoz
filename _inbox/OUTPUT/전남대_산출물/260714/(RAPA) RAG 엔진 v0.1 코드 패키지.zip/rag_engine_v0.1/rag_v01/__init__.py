"""RAG 엔진 v0.1 dense 검색 패키지."""

__version__ = "0.1.0"
