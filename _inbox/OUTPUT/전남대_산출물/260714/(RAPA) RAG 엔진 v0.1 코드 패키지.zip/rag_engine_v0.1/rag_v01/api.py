"""RAG 엔진 v0.1 FastAPI 애플리케이션."""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator

from rag_v01 import __version__
from rag_v01 import search as search_service
from rag_v01.config import COLLECTION_NAME, MODEL_NAME, PROJECT_ROOT
from rag_v01.embedding import resolve_embedding_devices

app = FastAPI(title="RAG Engine v0.1", version=__version__)
INDEX_PATH = PROJECT_ROOT / "rag_v01" / "static" / "index.html"


class SearchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    query: str = Field(min_length=1, max_length=500)
    top_k: int = Field(default=5, ge=1, le=20)

    @field_validator("query")
    @classmethod
    def reject_blank_query(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("검색어는 공백일 수 없습니다.")
        return value


class SearchResult(BaseModel):
    rank: int
    similarity: float
    distance: float
    document: str
    metadata: dict[str, Any]


class SearchResponse(BaseModel):
    query: str
    collection: str
    results: list[SearchResult]


@app.get("/", response_class=FileResponse)
def index() -> FileResponse:
    return FileResponse(INDEX_PATH, media_type="text/html; charset=utf-8")


@app.get("/api/status")
def status() -> dict[str, Any]:
    return {
        "version": __version__,
        "model": MODEL_NAME,
        "collection": COLLECTION_NAME,
        "document_count": search_service.get_collection().count(),
        "embedding_device": resolve_embedding_devices(),
    }


@app.post("/api/search", response_model=SearchResponse)
def search(payload: SearchRequest) -> SearchResponse:
    query = payload.query.strip()
    try:
        results = search_service.search_dense(query, payload.top_k)
    except search_service.EmptyCollectionError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return SearchResponse(query=query, collection=COLLECTION_NAME, results=results)
