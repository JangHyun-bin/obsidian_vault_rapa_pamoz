from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
from html import unescape
import json
from pathlib import Path
import re
from typing import Any

import pytest
from fastapi.testclient import TestClient

from rag_v01 import api
from rag_v01 import search as search_service


COLLECTION_NAME = "rapa_evidence_cnuh_v1"

# data/sample/corpus.jsonl의 통풍·병원이용 FAQ·식당 문서에서 선정했다.
REPRESENTATIVE_QUERIES = (
    "통풍 발작 때 콜히친은 언제 복용하나요?",
    "진료 예약은 어떻게 하나요?",
    "전남대병원 구내식당 이용시간이 어떻게 되나요?",
)
EXPECTED_REAL_TOP_ONE = {
    REPRESENTATIVE_QUERIES[0]: "mvpdoc_0a7db60c5dae_003",
    REPRESENTATIVE_QUERIES[1]: "mvpdoc_6c06446fc575_001",
    REPRESENTATIVE_QUERIES[2]: "mvpdoc_7b15850db61a_001",
}
CORPUS_PATH = Path(__file__).resolve().parents[1] / "data" / "sample" / "corpus.jsonl"
CORPUS_SHA256 = "2b50d8b6eb63339669bf3d9365f3136aa48c43f0dc76ce22182a7617801f43a2"

DOCUMENTS = [
    "통풍 발작이 시작되면 콜히친을 가능한 한 빨리 복용합니다.",
    "진료예약은 인터넷 또는 전화로 가능합니다.",
    "구내 식당은 8동 지하 1층에 있습니다.",
    "진단서와 증명서는 종류에 따라 발급처가 다릅니다.",
    "전남대병원 인근 버스 노선을 안내합니다.",
]
METADATAS = [
    {
        "source_org": "CNUH",
        "source_url": f"https://www.cnuh.com/example/{index}",
        "title": title,
        "order_marker": index,
    }
    for index, title in enumerate(
        ["통풍", "병원이용 FAQ", "식당·커피숍", "병원이용 FAQ", "병원주변약도"],
        start=1,
    )
]

# 음수와 1 초과 거리도 포함해 similarity clamp를 함께 고정한다.
DISTANCES = [-0.2, 0.12355, 0.5, 0.99996, 1.25]
EXPECTED_DISTANCES = [-0.2, 0.1235, 0.5, 1.0, 1.25]
EXPECTED_SIMILARITIES = [1.0, 0.8764, 0.5, 0.0, 0.0]
FAKE_VECTOR = [0.11, 0.22, 0.33]


@dataclass
class FakeCollection:
    document_count: int = 29
    query_calls: list[dict[str, Any]] = field(default_factory=list)

    def count(self) -> int:
        return self.document_count

    def query(self, *args: Any, **kwargs: Any) -> dict[str, list[list[Any]]]:
        self.query_calls.append({"args": args, "kwargs": kwargs})
        limit = int(kwargs.get("n_results", len(DOCUMENTS)))
        return {
            "documents": [DOCUMENTS[:limit]],
            "metadatas": [METADATAS[:limit]],
            "distances": [DISTANCES[:limit]],
        }


@dataclass
class FakeRuntime:
    client: TestClient
    collection: FakeCollection
    embedded_queries: list[str]


@pytest.fixture
def runtime(monkeypatch: pytest.MonkeyPatch) -> FakeRuntime:
    collection = FakeCollection()
    embedded_queries: list[str] = []

    def fake_embed_query(query: str) -> list[float]:
        embedded_queries.append(query)
        return FAKE_VECTOR

    # BGE-M3를 불러오지 않고 HTTP 계약만 검증한다.
    monkeypatch.setattr(search_service, "get_collection", lambda: collection)
    monkeypatch.setattr(search_service, "embed_query", fake_embed_query)

    with TestClient(api.app) as client:
        yield FakeRuntime(client, collection, embedded_queries)


def test_status_contract_without_loading_embedding(runtime: FakeRuntime) -> None:
    response = runtime.client.get("/api/status")

    assert response.status_code == 200
    payload = response.json()
    assert set(payload) == {
        "version",
        "model",
        "collection",
        "document_count",
        "embedding_device",
    }
    assert payload["version"] == "0.1.0"
    assert payload["model"] == "BAAI/bge-m3"
    assert payload["collection"] == COLLECTION_NAME
    assert payload["document_count"] == 29
    assert payload["embedding_device"] is None or isinstance(
        payload["embedding_device"],
        (str, list),
    )
    assert runtime.embedded_queries == []
    assert runtime.collection.query_calls == []


def test_empty_collection_requires_ingest(runtime: FakeRuntime) -> None:
    runtime.collection.document_count = 0

    response = runtime.client.post(
        "/api/search",
        json={"query": REPRESENTATIVE_QUERIES[0], "top_k": 5},
    )

    assert response.status_code == 503
    assert "인제스트 필요" in response.text
    assert runtime.embedded_queries == []
    assert runtime.collection.query_calls == []


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {"query": "", "top_k": 5},
        {"query": "   ", "top_k": 5},
        {"query": "가" * 501, "top_k": 5},
        {"query": "진료 예약", "top_k": 0},
        {"query": "진료 예약", "top_k": 21},
    ],
)
def test_search_request_validation_returns_422(
    runtime: FakeRuntime,
    payload: dict[str, Any],
) -> None:
    response = runtime.client.post("/api/search", json=payload)

    assert response.status_code == 422
    assert runtime.embedded_queries == []
    assert runtime.collection.query_calls == []


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("source_type", "faq"),
        ("source_org", "CNUH"),
        ("guardrail", True),
    ],
)
def test_v01_rejects_out_of_scope_search_fields(
    runtime: FakeRuntime,
    field: str,
    value: Any,
) -> None:
    payload = {"query": "진료 예약", "top_k": 5, field: value}

    response = runtime.client.post("/api/search", json=payload)

    assert response.status_code == 422
    assert any(error.get("type") == "extra_forbidden" for error in response.json()["detail"])
    assert runtime.embedded_queries == []
    assert runtime.collection.query_calls == []


@pytest.mark.parametrize("query", REPRESENTATIVE_QUERIES)
def test_representative_queries_return_ranked_top_five_with_sources(
    runtime: FakeRuntime,
    query: str,
) -> None:
    response = runtime.client.post("/api/search", json={"query": query, "top_k": 5})

    assert response.status_code == 200
    payload = response.json()
    assert set(payload) == {"query", "collection", "results"}
    assert payload["query"] == query
    assert payload["collection"] == COLLECTION_NAME

    results = payload["results"]
    assert len(results) == 5
    assert [item["rank"] for item in results] == [1, 2, 3, 4, 5]
    assert [item["distance"] for item in results] == EXPECTED_DISTANCES
    similarities = [item["similarity"] for item in results]
    assert similarities == EXPECTED_SIMILARITIES
    assert all(
        left >= right
        for left, right in zip(similarities, similarities[1:])
    )

    for index, item in enumerate(results):
        assert set(item) == {"rank", "similarity", "distance", "document", "metadata"}
        assert item["document"] == DOCUMENTS[index]
        assert item["metadata"] == METADATAS[index]
        assert item["metadata"]["source_org"]
        assert item["metadata"]["source_url"].startswith("https://")

    assert runtime.embedded_queries == [query]
    query_call = runtime.collection.query_calls[-1]
    assert query_call["kwargs"]["query_embeddings"] == [FAKE_VECTOR]
    assert query_call["kwargs"]["n_results"] == 5
    assert set(query_call["kwargs"]["include"]) == {"documents", "metadatas", "distances"}


def test_search_defaults_to_top_five(runtime: FakeRuntime) -> None:
    response = runtime.client.post("/api/search", json={"query": "진료 예약"})

    assert response.status_code == 200
    assert len(response.json()["results"]) == 5
    assert runtime.collection.query_calls[-1]["kwargs"]["n_results"] == 5


def test_root_renders_search_only_offline_ui(runtime: FakeRuntime) -> None:
    response = runtime.client.get("/")

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/html")
    source = response.text
    rendered_text = unescape(source)

    assert "RAG Engine v0.1" in source
    assert "전남대학교병원 안내 문서 dense 검색 데모" in source
    assert "검색 기능 데모입니다. 의료 상담·답변 기능이 아닙니다." in rendered_text
    assert re.search(r'<form[^>]+id="search-form"', source)
    assert re.search(r'<input[^>]+id="query"[^>]+type="search"', source)
    assert re.search(
        r'<input[^>]+id="top-k"[^>]+type="number"[^>]+min="1"[^>]+max="20"[^>]+value="5"',
        source,
    )
    assert 'id="results"' in source
    assert 'fetch("/api/search"' in source

    # 제출 HTTP 원문에는 상위 버전 UI 용어가 없어야 한다.
    for forbidden in ("답변", "가드레일", "라우팅", "로그인", "/api/answer"):
        assert forbidden not in source

    # 오프라인 시연을 위해 외부 스크립트·스타일시트를 참조하지 않는다.
    assert not re.search(
        r'<(?:script|link)\b[^>]*(?:src|href)=["\']https?://',
        source,
        flags=re.IGNORECASE,
    )


def test_only_v01_routes_are_exposed(runtime: FakeRuntime) -> None:
    response = runtime.client.get("/openapi.json")

    assert response.status_code == 200
    assert set(response.json()["paths"]) == {"/", "/api/status", "/api/search"}


def test_bundled_corpus_is_fixed_evidence_scope() -> None:
    assert hashlib.sha256(CORPUS_PATH.read_bytes()).hexdigest() == CORPUS_SHA256
    records = [
        json.loads(line)
        for line in CORPUS_PATH.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert len(records) == 29
    assert len({record["id"] for record in records}) == 29
    for record in records:
        assert set(record) == {"id", "document", "metadata"}
        assert record["document"]
        assert record["metadata"]["collection_target"] == COLLECTION_NAME
        assert record["metadata"]["source_org"]
        assert record["metadata"]["source_url"].startswith("https://")


@pytest.mark.parametrize("query", REPRESENTATIVE_QUERIES)
def test_real_persistent_search_returns_expected_top_five(query: str) -> None:
    # 수용 순서대로 scripts/ingest.py를 먼저 실행한 독립 DB를 실제로 검색한다.
    with TestClient(api.app) as client:
        response = client.post("/api/search", json={"query": query, "top_k": 5})

    assert response.status_code == 200
    payload = response.json()
    results = payload["results"]
    assert len(results) == 5
    similarities = [result["similarity"] for result in results]
    assert similarities == sorted(similarities, reverse=True)
    assert results[0]["metadata"]["chunk_id"] == EXPECTED_REAL_TOP_ONE[query]
    assert all(
        result["metadata"].get("source_org")
        and result["metadata"].get("source_url")
        for result in results
    )
