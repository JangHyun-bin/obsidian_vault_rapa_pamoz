#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="$ROOT/.venv/bin/python"
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-20013}"
LOG_FILE="${LOG_FILE:-$ROOT/rag_engine_v01.log}"
PID_FILE="${PID_FILE:-$ROOT/rag_engine_v01.pid}"

if [ ! -x "$PYTHON" ]; then
  echo "오류: 먼저 이 디렉터리에서 uv sync를 실행하세요." >&2
  exit 1
fi

if ! [[ "$PORT" =~ ^[0-9]+$ ]] || [ "$PORT" -lt 20000 ] || [ "$PORT" -gt 22000 ]; then
  echo "오류: PORT는 할당 범위 20000~22000 안의 정수여야 합니다." >&2
  exit 1
fi

cd "$ROOT"

if [ -f "$PID_FILE" ]; then
  pid="$(cat "$PID_FILE")"
  if [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null; then
    echo "오류: 서버가 이미 실행 중입니다(PID $pid)." >&2
    echo "로그: $LOG_FILE" >&2
    exit 1
  fi
  rm -f "$PID_FILE"
fi

if command -v ss >/dev/null 2>&1 && ss -ltn "sport = :$PORT" | tail -n +2 | grep -q .; then
  echo "오류: 포트 $PORT가 이미 사용 중입니다." >&2
  exit 1
fi

nohup setsid "$PYTHON" -m uvicorn rag_v01.api:app --host "$HOST" --port "$PORT" >> "$LOG_FILE" 2>&1 &
pid="$!"
echo "$pid" > "$PID_FILE"
disown "$pid" 2>/dev/null || true

echo "서버 시작 완료: PID $pid"
echo "접속: http://$HOST:$PORT"
echo "로그: $LOG_FILE"
